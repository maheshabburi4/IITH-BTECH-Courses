#ifndef DNSHEADER_H
#define DNSHEADER_H
#include<stdio.h> 
#include <endian.h>
struct dns_header {
	uint16_t id;
# if __BYTE_ORDER == __BIG_ENDIAN
	uint16_t qr:1;
	uint16_t opcode:4;
	uint16_t aa:1;
	uint16_t tc:1;
	uint16_t rd:1;
	uint16_t ra:1;
	uint16_t z:3;
	uint16_t rcode:4;
  
# elif __BYTE_ORDER == __LITTLE_ENDIAN
	uint16_t rd:1;
	uint16_t tc:1;
	uint16_t aa:1;
	uint16_t opcode:4;
	uint16_t qr:1;
	uint16_t rcode:4;
    uint16_t cd:1;
    uint16_t ad:1;
	uint16_t z:3;
	uint16_t ra:1; 

# else
#  error "Adjust your <bits/endian.h> defines"
# endif
	uint16_t q_count;	/* question count */
	uint16_t ans_count;	/* Answer record count */
	uint16_t auth_count;	/* Name Server (Autority Record) Count */ 
	uint16_t add_count;	/* Additional Record Count */
};
#endif