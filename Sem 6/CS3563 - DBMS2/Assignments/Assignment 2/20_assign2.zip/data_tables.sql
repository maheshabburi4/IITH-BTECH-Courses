CREATE TABLE title_akas
(
	titleId TEXT,
	ordering INTEGER,
	title TEXT,
	region TEXT,
	language TEXT,
	types TEXT,
	attributes TEXT,
	isOriginalTitle BOOLEAN,
	PRIMARY KEY(titleID,ordering)
);
--all done

CREATE TABLE title_basics
(
	tconst TEXT,
	titleType TEXT,
	primaryTitle TEXT,
	originalTitle TEXT,
	isAdult BOOLEAN,
	startyear INT,
	endyear INT,
	runtimeMinutes INT,
	genres TEXT,
	PRIMARY KEY(tconst)
);

CREATE TABLE title_crew
(
	tconst TEXT,
	directors TEXT,
	writers TEXT,
	PRIMARY KEY(tconst)
);

CREATE TABLE title_episode
(
	tconst TEXT,
	parentTconst TEXT,
	seasonNumber INTEGER,
	episodeNumber INTEGER,
	PRIMARY KEY(tconst)
);

CREATE TABLE title_principals
(
	tconst TEXT,
	ordering TEXT,
	nconst TEXT,
	category TEXT,
	job TEXT,
	characters TEXT,
	PRIMARY KEY(tconst,ordering)
);

CREATE TABLE title_ratings
(
	tconst TEXT,
	averageRating REAL,
	numVotes INTEGER,
	PRIMARY KEY(tconst)
);

CREATE TABLE name_basics
(
	nconst TEXT,
	primaryName TEXT,
	birthYear INT,
	deathYear INT,
	primaryProfession TEXT,
	--multivalued
	knownForTitles TEXT,
	--multivalued
	PRIMARY KEY(nconst)
);

CREATE TABLE budg
(
	tconst TEXT,
	budget INTEGER,
	revenue INTEGER
);

CREATE TABLE rat
(
	userid INTEGER,
	rating REAL,
	imdb_id TEXT
);

CREATE TABLE rev
(
	userid INTEGER,
	review TEXT,
	imdb_id TEXT
); 