COPY title_ratings
FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.ratings.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY title_episode FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.episode.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY title_crew FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.crew.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY title_basics FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.basics.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY name_basics FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/name.basics.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY title_akas FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.akas.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

COPY title_principals FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/title.principals.tsv'
(format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

------------- THESE FILES ARE NOT IN APRROPRIATE FORMAT. PLEASE IMPORT USING GUI LIKE PGADMIN4 ----------------
-- COPY production_company FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/production_company_ids.csv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');

-- COPY budg FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/budg_rev.tsv'
-- (format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

-- COPY rat FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/rat.tsv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');

-- COPY rev FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/rev.tsv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');