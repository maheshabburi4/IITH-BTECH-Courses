----------------------------------------------imdb table started----------------------------------------------

insert into imdb
	(imdb_id)
select tconst
from title_basics;

UPDATE imdb
SET rating = title_ratings.averagerating
FROM title_ratings
WHERE title_ratings.tconst = imdb.imdb_id;

UPDATE imdb                                                                                               
SET certificate =
 CASE 
  WHEN title_basics.isadult = FALSE THEN 'NOT A'
  WHEN title_basics.isadult = TRUE THEN 'A'
 end
FROM title_basics
WHERE title_basics.tconst = imdb.imdb_id;

UPDATE imdb
SET 
	parental_rating =
	CASE 
	when CERTIFICATE = 'A' THEN 'R'
	ELSE 'G'
END;

UPDATE imdb
SET	 
	runtime = title_basics.runtimeminutes 
from title_basics 
where title_basics.tconst = imdb.imdb_id
;


UPDATE imdb
SET 
	budget =  budg.budget,
	gross = budg.revenue 
from budg 
where budg.tconst = imdb.imdb_id;

UPDATE imdb
SET 
	start_year = title_basics.startyear,
	end_year = title_basics.endyear
from title_basics
where title_basics.tconst = imdb.imdb_id;

UPDATE imdb  
SET 
original_title = title_basics.originaltitle
FROM title_basics
WHERE title_basics.tconst = imdb.imdb_id;

----------------------------------------------imdb table ended----------------------------------------------

----------------------------------------------imdb_genre table started----------------------------------------------

insert into imdb_genre
	(imdb_id,genre)
select title_basics.tconst,
	regexp_split_to_table(title_basics.genres,E','
)
from title_basics;

----------------------------------------------imdb_genre table ended----------------------------------------------

----------------------------------------------movie table started----------------------------------------------

insert into movie
	(imdb_id)
select tconst
from title_basics
where title_basics.titletype='movie';

----------------------------------------------movie table ended----------------------------------------------

----------------------------------------------tv_series table ended----------------------------------------------

insert into tv_series
	(imdb_id)
select tconst
from title_basics
where title_basics.titletype = 'tvSeries';

UPDATE 
	tv_series
SET 
	running_status = 
	CASE 
	WHEN title_basics.endyear IS NULL THEN 'Running'
	ELSE 'Completed'
	END
FROM title_basics
WHERE title_basics.tconst = tv_series.imdb_id;

----------------------------------------------tv_series table ended----------------------------------------------

----------------------------------------------episode table started----------------------------------------------

insert into episode
	(episode_id)
select tconst
from title_episode;

UPDATE episode                                                                                           
SET                  
season_number = title_episode.seasonnumber,
 episode_number = title_episode.episodenumber,
 imdb_id = title_episode.parenttconst		--parent tv series id
FROM title_episode
WHERE title_episode.tconst = episode.episode_id;

UPDATE episode                                                                                           
SET 
parental_rating_ =
 CASE                                      
  WHEN title_basics.isadult = FALSE THEN 'G'
  WHEN title_basics.isadult = TRUE THEN 'R'  
 end,
certificate = 
 CASE                                      
  WHEN title_basics.isadult = FALSE THEN 'NOT A'
  WHEN title_basics.isadult = TRUE THEN 'A'  
 end
FROM title_basics
WHERE title_basics.tconst = episode.episode_id;


UPDATE episode                                                                                           
SET 
original_title = title_basics.originaltitle
FROM title_basics
WHERE title_basics.tconst = episode.episode_id;

UPDATE episode
SET 
	release_year = title_basics.startyear
from title_basics
where title_basics.tconst = episode.episode_id;

UPDATE EPISODE
SET	 
	runtime = title_basics.runtimeminutes 
from title_basics 
where title_basics.tconst = episode.episode_id
;


UPDATE episode
SET rating = title_ratings.averagerating
FROM title_ratings
WHERE title_ratings.tconst = episode.episode_id;

----------------------------------------------episode table ended----------------------------------------------

----------------------------------------------person table started----------------------------------------------

insert into person
	(person_id, dob, primary_name)
select nconst, birthyear, primaryname
from name_basics;

UPDATE person
SET 
	knownfor = name_basics.knownfortitles
from name_basics
where name_basics.nconst = person.person_id;

----------------------------------------------person table ended----------------------------------------------

-------------------------------------cast_crew table started---------------------------------------------------------------------------

insert into cast_crew
	(imdb_id,person_id, profession)
select tconst, nconst, category
from title_principals
	join person p on p.person_id = title_principals.nconst
	join imdb i on i.imdb_id = title_principals.tconst;

----------------------------------------------cast_crew table ended--------------------------------------------------

----------------------------------------------cast_crew_ep table started----------------------------------------------

insert into cast_crew_ep
	(episode_id,person_id, profession)
select tconst, nconst, category
from title_principals
	join person p on p.person_id = title_principals.nconst
	join episode e on e.episode_id = title_principals.tconst;

----------------------------------------------cast_crew_ep table ended----------------------------------------------

----------------------------------------------language1 table started----------------------------------------------

insert into language1
	(name)
select distinct(language)
from title_akas;

----------------------------------------------language1 table ended----------------------------------------------

----------------------------------------------imdb_lang table started----------------------------------------------

alter table imdb_lang disable trigger all;

insert into imdb_lang
	(imdb_id,title,lang_id)
select title_akas.titleid, title_akas.title, language1.lang_id
from title_akas join language1 on (language1.name = title_akas.language) or (language1.name is null and title_akas.language is null);


delete from imdb_lang 
where not EXISTS
( select imdb_id
from imdb
where  imdb_lang.imdb_id = imdb.imdb_id );

alter table imdb_lang enable trigger all;

----------------------------------------------imdb_lang table ended----------------------------------------------

----------------------------------------------location table started----------------------------------------------

insert into location1
	(region)
select distinct(region)
from title_akas;

----------------------------------------------location table ended----------------------------------------------

----------------------------------------------episode_info table started----------------------------------------------

insert into episode_info
	(episode_id,episode_name,location_id)
select ti.titleid, ti.title, location1.location_id
from title_akas ti
	JOIN episode on episode.episode_id = ti.titleid
	JOIN location1 on (ti.region = location1.region or (ti.region is null and location1.region is null));

----------------------------------------------episode_info table ended----------------------------------------------

----------------------------------------------series_info table started----------------------------------------------

insert into series_info
	(tv_series_id,series_name,location_id)
select tv_series.tv_series_id, ti.title, location1.location_id
from title_akas ti
	JOIN tv_series on tv_series.imdb_id = ti.titleid
	JOIN location1 on (ti.region = location1.region or (ti.region is null and location1.region is null));

----------------------------------------------series_info table ended----------------------------------------------

----------------------------------------------movie_info table started----------------------------------------------

insert into movie_info
	(movie_id,movie_name,location_id)
select movie.movie_id, ti.title, location1.location_id
from title_akas ti
	JOIN movie on movie.imdb_id = ti.titleid
	JOIN location1 on (ti.region = location1.region or (ti.region is null and location1.region is null));

----------------------------------------------movie_info table ended----------------------------------------------

----------------------------------------------users table started----------------------------------------------


insert into users
	(user_id)
select distinct(userid)
from rat;


insert into users
	(user_id)
select distinct(userid)
from rev
on conflict
(user_id) DO NOTHING;

----------------------------------------------users table ended----------------------------------------------

----------------------------------------------registered_user table started----------------------------------------------

alter table registered_user disable trigger all;

insert into registered_user
	(imdb_id,user_id,review)
select imdb_id, userid, review
from rev;

UPDATE registered_user
 SET
 rating = rat.rating
 from rat
 WHERE registered_user.user_id = rat.userid
	and registered_user.imdb_id = rat.imdb_id;


insert into registered_user
	(imdb_id,user_id,rating)
select imdb_id, userid, rating
from rat;

delete from registered_user
where not exists
(select imdb_id
from imdb
where imdb.imdb_id = registered_user.imdb_id
);


alter table registered_user enable trigger all;

----------------------------------------------registered_user table ended----------------------------------------------

----------------------------------------------registered_user_ep table started----------------------------------------------

alter table registered_user_ep disable trigger all;

insert into registered_user_ep
	(episode_id,user_id,review)
select imdb_id, userid, review
from rev;

UPDATE registered_user_ep
 SET
 rating = rat.rating
 from rat
 WHERE registered_user_ep.user_id = rat.userid
	and registered_user_ep.episode_id = rat.imdb_id;

insert into registered_user_ep
	(episode_id,user_id,rating)
select imdb_id, userid, rating
from rat;

delete from registered_user_ep
where not exists
(select episode_id
from episode
where episode.episode_id = registered_user_ep.episode_id
);

alter table registered_user_ep enable trigger all;

----------------------------------------------registered_user table ended----------------------------------------------


-------------------------------------------------------THE END ----------------------------------------------