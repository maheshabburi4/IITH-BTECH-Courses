CREATE TABLE Imdb
(
    Imdb_ID TEXT ,
    original_title TEXT ,
    gross TEXT ,
    budget TEXT ,
    plot_outline TEXT ,
    rating REAL ,
    Parental_rating TEXT ,
    certificate TEXT ,
    shoot_locations TEXT,
    streaming_site TEXT,
    anti_social_elements TEXT,
    runtime TEXT,
    start_year TEXT,
    end_year TEXT,
    PRIMARY KEY
  (Imdb_ID)
);
--all done

CREATE TABLE Tv_series
(
    Tv_series_ID SERIAL,
    running_status TEXT ,
    Imdb_ID TEXT ,
    PRIMARY KEY (Tv_series_ID),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);
--all done

CREATE TABLE Movie
(
    Movie_ID BIGSERIAL ,
    Imdb_ID TEXT ,
    PRIMARY KEY (Movie_ID),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);
--all done

CREATE TABLE Episode
(
    Episode_id TEXT,
    Season_number TEXT ,
    Episode_number TEXT ,
    Parental_rating_ TEXT ,
    rating REAL ,
    Original_Title TEXT ,
    imdb_id TEXT,
    runtime TEXT,
    release_year TEXT,
    certificate TEXT,
    PRIMARY KEY (Episode_id)
);
--all done

CREATE TABLE Location1
(
    region TEXT ,
    Location_ID SERIAL ,
    PRIMARY KEY (Location_ID),
    UNIQUE (region)
);
--all done

CREATE TABLE Person
(
    Person_ID TEXT ,
    primary_name TEXT,
    DOB INTEGER ,
    --year
    knownfor TEXT,
    PRIMARY KEY (Person_ID)
);
--all done

CREATE TABLE Award
(
    Award_ID TEXT ,
    Year TEXT ,
    Award_name TEXT ,
    category TEXT ,
    PRIMARY KEY (Award_ID, Year)

);
--all done

CREATE TABLE Production_Company
(
    Company_ID INTEGER ,
    name TEXT ,
    PRIMARY KEY (Company_ID)
);
--all done

CREATE TABLE Users
(
    User_ID INTEGER ,
    email TEXT ,
    PRIMARY KEY (User_ID)
);
--all done 

CREATE TABLE Language1
(
    name TEXT ,
    Lang_id SERIAL,
    PRIMARY KEY (Lang_id)
);
--all done

CREATE TABLE Sound_track
(
    Sound_track_ID TEXT ,
    name TEXT ,
    Imdb_ID TEXT ,
    PRIMARY KEY (Sound_track_ID),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);
--all done

CREATE TABLE series_info
(
    series_name TEXT ,
    Tv_series_ID INTEGER ,
    Location_ID INTEGER,
    FOREIGN KEY (Tv_series_ID) REFERENCES Tv_series(Tv_series_ID),
    FOREIGN KEY (Location_ID) REFERENCES Location1(Location_ID)
);
--all done

CREATE TABLE movie_info
(
    movie_name TEXT,
    Movie_ID INTEGER ,
    Location_ID INTEGER ,
    FOREIGN KEY (Movie_ID) REFERENCES Movie(Movie_ID),
    FOREIGN KEY (Location_ID) REFERENCES Location1(Location_ID)
);
--all done

CREATE TABLE episode_info
(
    episode_name TEXT ,
    Location_ID INTEGER,
    Episode_id TEXT,
    FOREIGN KEY (Location_ID) REFERENCES Location1(Location_ID),
    FOREIGN KEY (Episode_id) REFERENCES Episode(Episode_id)
);
--all done		

CREATE TABLE cast_crew_ep
(
    profession TEXT,
    Episode_id TEXT,
    Person_ID TEXT ,
    FOREIGN KEY (Episode_id ) REFERENCES Episode(Episode_id),
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID)
);
--all done

CREATE TABLE cast_crew
(
    profession TEXT,
    Imdb_ID TEXT ,
    Person_ID TEXT ,
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID),
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID)
);
--all done

CREATE TABLE nominated
(
    won_not TEXT ,
    Award_ID TEXT ,
    Year TEXT,
    Imdb_ID TEXT ,
    FOREIGN KEY (Award_ID, Year) REFERENCES Award(Award_ID, Year),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);
--all done

CREATE TABLE nominated_person
(
    imdb_ID TEXT ,
    won_not TEXT ,
    Award_ID TEXT ,
    Year TEXT,
    Person_ID TEXT ,
    FOREIGN KEY (Award_ID, Year) REFERENCES Award(Award_ID, Year),
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID)
);
--all done

CREATE TABLE produced_by
(
    Imdb_ID TEXT ,
    Company_ID INTEGER ,
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID),
    FOREIGN KEY (Company_ID) REFERENCES Production_Company(Company_ID)
);
--all done

CREATE TABLE registered_user
(
    rating REAL ,
    review TEXT ,
    Imdb_ID TEXT ,
    User_ID INTEGER ,
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID),
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID)
);
--all done

CREATE TABLE imdb_lang
(
    title TEXT,
    Imdb_ID TEXT,
    ordering SERIAL,
    lang_id INTEGER,
    PRIMARY KEY (ordering),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID),
    FOREIGN KEY (lang_id) REFERENCES Language1(lang_id)
);
--all done

CREATE TABLE registered_user_ep
(
    rating REAL ,
    review TEXT ,
    User_ID INTEGER,
    Episode_id TEXT,
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID),
    FOREIGN KEY (Episode_id) REFERENCES Episode(Episode_id)
);
--all done

CREATE TABLE episode_st
(
    Sound_track_Id TEXT ,
    Episode_id TEXT,
    FOREIGN KEY (Sound_track_Id) REFERENCES Sound_track(Sound_track_ID),
    FOREIGN KEY (Episode_id) REFERENCES Episode(Episode_id)
);
--all done 

CREATE TABLE directed_by
(
    Person_ID TEXT ,
    Sound_track_ID TEXT ,
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID),
    FOREIGN KEY (Sound_track_ID) REFERENCES Sound_track(Sound_track_ID)
);
--all done  

CREATE TABLE Imdb_genre
(
    genre TEXT ,
    Imdb_ID TEXT ,
    PRIMARY KEY (genre, Imdb_ID),
    FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);				
--all done