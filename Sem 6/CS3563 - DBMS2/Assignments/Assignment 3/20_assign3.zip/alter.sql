-----------------------------------------------imdb table altered started-----------------------------------------------------------

---------------- shoot locations started -----------------------------
--dropping shoot locations as attribute
alter table imdb
drop column shoot_locations;

-- create new table for shoot location(multi variable attribute)
CREATE TABLE shoot_location
(
	imdb_id TEXT,
	region TEXT,
	FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);

--Import the file using UI like PGADMIN 4 recommended
-- COPY shoot_locations FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/filming_locations.csv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');

-------------- shoot locations completed ------------------------------

------------- title type started --------------------------------------
-- adding title type attribute
ALTER TABLE imdb
ADD title_type text;

UPDATE imdb
SET 
	title_type = title_basics.titletype
from title_basics 
where imdb.imdb_id =  title_basics.tconst;
------------ title type ended ----------------------------------------

----------- updating budg data started---------------------------------------
-- drop before data as budget and revenue cannot hold in integer
drop table budg;

-- create table with budget, revenue as biginteger
CREATE TABLE budg
(
	tconst TEXT,
	budget BIGINT,
	revenue BIGINT
);

--Import the file using UI like PGADMIN 4 recommended
-- COPY budg FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/budg_rev.tsv'
-- (format csv, DELIMITER E'\t', HEADER 1, NULL '\N', quote E'\f');

--updating the budget and gross from the updated data
UPDATE imdb
SET 
	budget =  budg.budget,
	gross = budg.revenue 
from budg 
where budg.tconst = imdb.imdb_id;
----------- updating budg data completed---------------------------------------

------------------------------------------------imdb table altered ended---------------------------------------------------------------

----------------------------------------------produced_by table started----------------------------------------------------------------
---before importing need to disable triggers for foriegn constraints errors
alter table produced_by disable trigger all;

--Import the file using UI like PGADMIN 4 recommended
-- COPY produced_by FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/produced_by.csv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');

-- delete rows not following foriegn key constraints
delete from produced_by
where not exists
( select company_id
from production_company
where produced_by.company_id = production_company.company_id );

--- enable the trigger to detect constarints
alter table produced_by enable trigger all;

-----------------------------------------------produced_by ended----------------------------------------------------------------------

-----------------------------------------------award_data for importing award data-----------------------------------------------------
CREATE TABLE award_data
(
	YEAR text,
	Award_name text,
	category text,
	won_not text,
	person_id text,
	movie_id text
);

--Import the file using UI like PGADMIN 4 recommended
-- COPY award_data FROM '/home/balaram/Desktop/programs/DBMS/Assignment-2/Data-Sets/Award.csv'
-- (format csv, DELIMITER E',', HEADER 1, NULL '\N', quote E'\f');

----------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------award table started-------------------------------------------------------
--foreign key constaints, should be dropped first
drop table nominated;
drop table nominated_person;
drop table Award;

CREATE TABLE Award
(
	Award_ID BIGSERIAL ,
	Year TEXT ,
	Award_name TEXT ,
	category TEXT ,
	PRIMARY KEY (Award_ID)

);

insert into award
	(year,award_name,category)
select distinct year, award_name, category
from award_data;

---------------------------------------------award table ended-------------------------------------------------------

---------------------------------------------nominated table started-------------------------------------------------------

CREATE TABLE nominated
(
	won_not TEXT ,
	Award_ID BIGINT ,
	Imdb_ID TEXT ,
	FOREIGN KEY (Award_ID) REFERENCES Award(Award_ID),
	FOREIGN KEY (Imdb_ID) REFERENCES Imdb(Imdb_ID)
);

insert into nominated
	(award_id,won_not,imdb_id)
select award_id, won_not, movie_id
from award, award_data
where award.year = award_data.year and award.award_name = award_data.award_name
	and award.category = award_data.category and movie_id is not null;

UPDATE nominated
set won_not  = 
	CASE 
	WHEN won_not = '1' then 'won'
	ELSE 'not won'
	end;
---------------------------------------------nominated table ended-------------------------------------------------------

---------------------------------------------nominated_person table started-------------------------------------------------------

CREATE TABLE nominated_person
(
	imdb_ID TEXT ,
	won_not TEXT ,
	Award_ID BIGINT,
	Person_ID TEXT ,
	FOREIGN KEY (Award_ID) REFERENCES Award(Award_ID),
	FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID)
);

insert into nominated_person
	(award_id,won_not,imdb_id,person_id)
select award_id, won_not, movie_id, person_id
from award, award_data
where award.year = award_data.year and award.award_name = award_data.award_name
	and award.category = award_data.category and person_id is not null;

UPDATE nominated_PERSON
set won_not  = 
	CASE 
	WHEN won_not = '1' then 'won'
	ELSE 'not won'
	end;
---------------------------------------------nominated_person ended-------------------------------------------------------

-----------------------------------------------cast_crew table altered started ------------------------------------------------------

ALTER TABlE cast_crew
add job text;

UPDATE cast_crew
SET job = title_principals.job
from title_principals
where cast_crew.imdb_id = title_principals.tconst
	and cast_crew.person_id = title_principals.nconst
	and cast_crew.profession = title_principals.category;
-----------------------------------------------cast_crew table altered completd ------------------------------------------------------

-----------------------------------------------drop unnecessary tables started-----------------------------------------------------------------------------

drop table directed_by;
drop table episode_st;
drop table sound_track;

-----------------------------------------------drop unnecessary tables completed-----------------------------------------------------------------------------
