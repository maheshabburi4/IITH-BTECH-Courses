------------Query 1-----------------------

select original_title, director_count
from
    (select imdb_id, count(imdb_id) director_count
    from
        (select cast_crew.imdb_id
        from
            cast_crew
            join movie
            on cast_crew.profession='director' and cast_crew.imdb_id = movie.imdb_id ) as my
    group by imdb_id
    having count(imdb_id)>=2) t1,
    imdb
where t1.imdb_id = imdb.imdb_id;

------------------------------------------

-------------Query 2------------------------------------------

WITH
    zack_view(persons_id, zack_id, with_zack)
    as
    (
        select t1.person_id, zack_id , count(t1.imdb_id)
        from
            (select *
            from
                cast_crew
            where profession='actor') t1,
            (select imdb_id, t10.zack_id
            from
                cast_crew,
                (select (person_id)zack_id
                from
                    person
                where primary_name ='Zack Snyder')t10
            where zack_id = cast_crew.person_id and profession='director') t2,
            imdb
        where t1.imdb_id = t2.imdb_id and t1.imdb_id = imdb.imdb_id and imdb.title_type = 'movie'
        group by t1.person_id,zack_id
    ) ,
    director_pair(actor_id, max_count)
    as
    (
        select t9.actor_id, max(pairs)
        from
            (select (t4.person_id) actor_id, (t5.person_id) director_id, count(t4.imdb_id) pairs
            from
                (select imdb_id, cast_crew.person_id
                from
                    zack_view,
                    cast_crew
                where cast_crew.profession='actor' and zack_view.persons_id = cast_crew.person_id)t4,
                (select person_id, imdb_id
                from
                    cast_crew,
                    (select (person_id)zack_id
                    from
                        person
                    where primary_name ='Zack Snyder') t20
                where profession='director' and person_id!=t20.zack_id )t5,
                imdb
            where t4.imdb_id = t5.imdb_id and t4.imdb_id = imdb.imdb_id and imdb.title_type='movie'
            group by t4.person_id,t5.person_id) t9
        group by actor_id
    )

select primary_name, with_zack, max_count
from
    person,
    (select zack_view.persons_id, with_zack, max_count
    from
        director_pair,
        zack_view
    where director_pair.actor_id = zack_view.persons_id and with_zack > max_count) t6
where t6.persons_id = person.person_id;

--------------------------------------------------

-------------Query 3----------------------
select original_title, number_awards
from
    (select imdb_id, count(imdb_id) number_awards
    from
        (select nominated.imdb_id
        from
            nominated
            join movie
            on nominated.imdb_id= movie.imdb_id and nominated.won_not ='won') my
    group by imdb_id
    having count(imdb_id)<2) t1,
    imdb
where t1.imdb_id = imdb.imdb_id;

-----------------------------------------

---------------------------Query 4-----------------------------------------

select (p1.primary_name) actor_name, (p2.primary_name) director_name, pair_count
from
    (select (t1.person_id) actor, (t2.person_id) director, count(t3.imdb_id) pair_count
    from
        (select imdb_id
        from
            imdb
        where title_type='movie' and rating > 7 ) t3,
        (select person_id, imdb_id
        from
            cast_crew
        where profession='actor') t1,
        (select person_id, imdb_id
        from
            cast_crew
        where profession='director') t2
    where t3.imdb_id = t1.imdb_id and t3.imdb_id = t2.imdb_id
    group by t1.person_id,t2.person_id) t4,
    person p1,
    person p2
where pair_count > 0 and pair_count <=2 and p1.person_id = t4.actor and p2.person_id = t4.director
order by(actor_name);

---------------------------------------------------------------------------

----------------Query 5----------------------------------------------------

select original_title, maxi
from
    (select original_title, (cast(end_year as int) - cast(start_year as int)) as maxi,
        dense_rank() over (order by cast(end_year as int) - cast(start_year as int) desc) as r1
    from
        (select original_title, start_year,
            (CASE 
                WHEN end_year IS NULL THEN '2021'
                ELSE end_year 
            END) end_year
        from
            imdb
        where imdb.title_type='tvSeries' and start_year is not null and cast(start_year as int) <=2021) as my
    ) as mt
where r1 = 1;

---------------------------------------------------------------------------

---------------Query 6-----------------------------------------------------

select primary_name, original_title, runtime
from
    (select ti.imdb_id, runtime, cast_crew.person_id, original_title
    from
        (select imdb_id, runtime, original_title,
            dense_rank() over (order by cast(runtime as int) asc) as r1
        from
            imdb
        where imdb.start_year='2020' and imdb.title_type='movie') ti
        join cast_crew
        on ti.r1=2 and cast_crew.profession='director' and cast_crew.imdb_id = ti.imdb_id) as my
    join person
    on person.person_id = my.person_id;

---------------------------------------------------------------------------

---------------Query 7-----------------------------------------------------

select original_title, rating, certificate
from
    (select *,
        dense_rank() over (order by cast(rating as real) asc) as r1
    from
        imdb
    where title_type='movie' and certificate='A' and rating is not null) as mt
where r1 = 1;

select original_title, rating, certificate
from
    (select *,
        dense_rank() over (order by cast(rating as real) asc) as r1
    from
        imdb
    where title_type='tvSeries' and certificate='A' and rating is not null) as mt
where r1 = 1;

---------------------------------------------------------------------------

------------------------Query 8--------------------------------------------

select *
from
    (select person_id, avg(rating) as avg_rat,
        dense_rank() over (order by avg(rating) desc) as r1
    from
        (select *
        from
            cast_crew
            join imdb
            on rating is not null and imdb.title_type='movie' and cast_crew.profession='director'
                and cast_crew.imdb_id = imdb.imdb_id) as mt
    group by person_id) as my
where r1<=5;

------------------------------------------------------------------------------

------------------------Query 9-----------------------------------------------

select original_title
from
    (select t1.imdb_id, count(location_id) location_count
    from
        (select imdb.imdb_id, count(company_id) number_of_companies
        from
            imdb,
            produced_by
        where title_type = 'tvSeries' and imdb.imdb_id = produced_by.imdb_id
        group by imdb.imdb_id) t1,
        tv_series,
        series_info
    where t1.number_of_companies >=2 and tv_series.imdb_id = t1.imdb_id
        and tv_series.tv_series_id = series_info.tv_series_id and location_id != 1
    group by t1.imdb_id) t2,
    imdb
where t2.location_count > 3 and t2.imdb_id = imdb.imdb_id;

------------------------------------------------------------------------------

-----------------------------------Query 10-----------------------------------

select primary_name, year
from
    nominated_person,
    award,
    person
where won_not = 'won' and award.award_id = nominated_person.award_id
    and nominated_person.person_id = person.person_id and award.category like '%Actor%'
order by cast(year as int) desc;

------------------------------------------------------------------------------

-----------------------------------Query 11-----------------------------------

select primary_name,
    (0.3*( COALESCE(director_exp,0) + COALESCE(asst_director_exp,0)) + 0.7*(0.8*COALESCE(director_rating,0) + 0.2*COALESCE(asst_director_rating,0))) score
from
    (select COALESCE(t1.person_id,t2.person_id) as person_id, director_exp, director_rating, asst_director_exp, asst_director_rating
    from
        (select person_id, count(cast_crew.imdb_id) director_exp, avg(rating) director_rating
        from
            cast_crew,
            imdb
        where imdb.title_type = 'movie' and job = 'director' and cast_crew.imdb_id = imdb.imdb_id
        group by person_id) t1
        full outer join
        (select person_id, count(cast_crew.imdb_id) asst_director_exp, avg(rating) asst_director_rating
        from
            cast_crew,
            imdb
        where imdb.title_type = 'movie' and job = 'assistant director' and cast_crew.imdb_id = imdb.imdb_id
        group by person_id) t2
        on t1.person_id = t2.person_id) t3,
    person
where t3.person_id = person.person_id
order by score desc;

------------------------------------------------------------------------------

-----------------------------------Query 12-----------------------------------

select genre, original_title, (primary_name)director_name, (cast(gross as bigint) - cast(budget as bigint)) as earning, profit_rnk
from
    (select original_title, genre, cast_crew.person_id, budget, gross, profit_rnk
    from
        (select *
        from
            (select *,
                dense_rank() over (partition by genre order by (cast(gross as bigint) - cast(budget as bigint)) desc) as profit_rnk
            from
                (select imdb.imdb_id, imdb.original_title, genre, budget, gross
                from
                    imdb,
                    imdb_genre
                where imdb.title_type='movie' and budget is not null and gross is not null
                    and gross !='0' and imdb.imdb_id = imdb_genre.imdb_id ) t1
            ) t2
        where profit_rnk <=5) t3,
        cast_crew
    where cast_crew.profession='director' and cast_crew.imdb_id = t3.imdb_id
    order by t3.genre, t3.profit_rnk) t4,
    person
where t4.person_id = person.person_id;

-------------------------------------------------------------------------------

--------------------------------Query 13----------------------------------------

select (person.primary_name)Actor_name
from
    (select distinct(m1.person_id)
    from
        (select distinct(cast_crew.person_id)
        from
            imdb
            join cast_crew
            on imdb.title_type = 'movie' and cast_crew.profession='actor' and imdb.imdb_id = cast_crew.imdb_id) m1,
        (select distinct(cast_crew.person_id)
        from
            imdb
            join cast_crew
            on imdb.title_type = 'tvSeries' and cast_crew.profession='actor' and imdb.imdb_id = cast_crew.imdb_id) m2
    where m1.person_id = m2.person_id ) m3,
    person
where m3.person_id = person.person_id
order by person.person_id;

---------------------------------------------------------------------------

--------------------------------Query 14--------------------------------

select original_title, runtime, start_year
from
    (select *,
        dense_rank() over (partition by start_year order by runtime asc) runtime_rnk
    from
        (select *
        from
            imdb
        where title_type='tvEpisode' and runtime is not null and start_year is not null) t1
    ) t2
where runtime_rnk = 1;

--------------------------------------------------------------------------

--------------------------------Query 15----------------------------------

select *
from
    (select *,
        dense_rank() over (partition by genre order by rating desc) as genre_rnk
    from
        (select imdb.imdb_id, genre, original_title, rating
        from
            imdb,
            imdb_genre
        where imdb.title_type='movie' and rating is not null
            and imdb.imdb_id = imdb_genre.imdb_id) t1
    ) t2
where genre_rnk <=3;

--------------------------------------------------------------------------

--------------------------------Query 16----------------------------------

select original_title, title_type
from
    imdb,
    shoot_location
where imdb.imdb_id = shoot_location.imdb_id and region='Switzerland'
    and (title_type ='movie' or title_type='tvSeries');

--------------------------------------------------------------------------

--------------------------------Query 17----------------------------------

select movie_name, region
from
    (select *
    from
        (select movie_id
        from
            imdb,
            movie
        where certificate='A' and start_year = '1995' and title_type = 'movie' and movie.imdb_id = imdb.imdb_id) t1,
        movie_info
    where movie_info.movie_id = t1.movie_id
    order by location_id) t2,
    location1
where location1.location_id = t2.location_id and region is not null;

--------------------------------------------------------------------------

--------------------------------Query 18----------------------------------

select primary_name, profession, (dob) Year_of_birth
from
    (select *,
        dense_rank() over (partition by profession order by dob desc ) age_rnk
    from
        (select distinct cast_crew.person_id, cast_crew.profession, person.primary_name, person.dob
        from
            cast_crew,
            person
        where cast_crew.person_id = person.person_id and dob is not null ) t1
    ) t2
where age_rnk = 1;

--------------------------------------------------------------------------

--------------------------------Query 19----------------------------------

select primary_name, number_of_movies
from
    (select person_id, count(cast_crew.imdb_id) number_of_movies
    from
        cast_crew,
        imdb
    where (profession = 'composer' or profession ='archive_sound' or job like '%music producer%')
        and title_type='movie' and imdb.imdb_id = cast_crew.imdb_id
    group by (person_id)) t1,
    person
where t1.person_id = person.person_id and number_of_movies>=5;


-- select primary_name, number_of_movies
-- from
--     (select person_id, count(cast_crew.imdb_id) number_of_movies
--     from
--         cast_crew,
--         imdb
--     where (job like '%music producer%') and title_type='movie' and imdb.imdb_id = cast_crew.imdb_id
--     group by (person_id)) t1,
--     person
-- where t1.person_id = person.person_id and number_of_movies>=5;
--only music producer

--------------------------------------------------------------------------

-------------------------Query 20-----------------------------------------

select primary_name, acted, number_crew
from
    (select person_id, count(imdb_id) acted
    from
        cast_crew
    where cast_crew.profession='actor'
    group by person_id) t1,
    (select count(*) number_crew
    from
        (select imdb_id
        from
            imdb
        where original_title='Mission: Impossible - Fallout' and title_type = 'movie') t2,
        cast_crew
    where t2.imdb_id = cast_crew.imdb_id) t3,
    person
where number_crew = acted and t1.person_id = person.person_id;

-----------------------------------------------------------------------