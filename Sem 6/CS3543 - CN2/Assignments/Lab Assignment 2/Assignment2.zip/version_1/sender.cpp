#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/time.h>
#define BUFSIZE 4096
#define NUM_THREADS 100
#define TIMEOUT 500000
#define MAXRETRANS 200
#define WINDOWSIZE 10
using namespace std;
using namespace std::chrono;

/* Packet Structure */
struct Packet
{
    int SeqNum;
    int length;
    bool ACK;
    long long int sent_time;
    long long int exp_recv_time;
    char data[BUFSIZE];
};
vector<Packet> file_packets;
bool sendfail;

/* Function for threads */
void thread_function(int thread_id, int sendSocket, struct sockaddr_in *sendSockAddressInfo)
{
    /* Required Variables */
    int start_frame = thread_id * ceil(file_packets.size() / NUM_THREADS);
    int end_frame = min((thread_id + 1) * (int)ceil(file_packets.size() / NUM_THREADS), (int)file_packets.size());
    for (int i = start_frame; i < end_frame; i++)
    {
        for (int j = 0; j < MAXRETRANS && !file_packets[i].ACK; j++)
        {
            sendto(sendSocket, &file_packets[i], sizeof(file_packets[i]), 0, (struct sockaddr *)sendSockAddressInfo, sizeof(struct sockaddr_in));
            struct timeval present_time;
            gettimeofday(&present_time, 0);
            long long int present = present_time.tv_sec * 1000000 + present_time.tv_usec;
            file_packets[i].sent_time = present;
            file_packets[i].exp_recv_time = present + TIMEOUT;
            while (!file_packets[i].ACK && present < file_packets[i].exp_recv_time && !sendfail)
            {
                gettimeofday(&present_time, 0);
                present = present_time.tv_sec * 1000000 + present_time.tv_usec;
            }
            if (sendfail)
                return;
        }
        if (!file_packets[i].ACK)
            sendfail = true;
        if (sendfail)
            return;
    }
    // cout << "Thread # " << thread_id << "\n";
}

/* Main Function */
int main(int argc, char **argv)
{
    /* Check for Appropriate Command line arguments */
    if (argc != 4)
    {
        printf("Sender: Usage --> ./[%s] [Recieve Port Number] [Send IP Address] [Send Port Number] \n", argv[0]);
        exit(EXIT_FAILURE);
    }

    /* Send Socket Address Info */
    struct sockaddr_in sendSockAddressInfo;
    memset(&sendSockAddressInfo, 0, sizeof(sendSockAddressInfo));
    sendSockAddressInfo.sin_family = AF_INET;
    sendSockAddressInfo.sin_port = htons(atoi(argv[3]));
    sendSockAddressInfo.sin_addr.s_addr = inet_addr(argv[2]);

    /* Recieve Socket Address Info */
    struct sockaddr_in recieveSockAddressInfo;
    memset(&recieveSockAddressInfo, 0, sizeof(recieveSockAddressInfo));
    recieveSockAddressInfo.sin_family = AF_INET;
    recieveSockAddressInfo.sin_port = htons(atoi(argv[1]));
    recieveSockAddressInfo.sin_addr.s_addr = INADDR_ANY;

    /* Create Send Socket */
    int sendSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (!sendSocket)
    {
        cout << "Error creating send socket" << endl;
        exit(EXIT_FAILURE);
    }

    /* Create Recieve Socket */
    int recieveSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (!recieveSocket)
    {
        cout << "Error creating recieve socket" << endl;
        exit(EXIT_FAILURE);
    }

    /* Binding Recieve Socket */
    int ret = bind(recieveSocket, (struct sockaddr *)&recieveSockAddressInfo, sizeof(struct sockaddr));
    if (ret < 0)
    {
        cout << "Error binding recieve socket" << endl;
        close(recieveSocket);
        exit(EXIT_FAILURE);
    }

    /* Set timeout for Recieve Socket */
    struct timeval t_out = {0, 0};
    t_out.tv_sec = 0;
    t_out.tv_usec = TIMEOUT;
    setsockopt(recieveSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval));

    /* Required Variables of to store from Address */
    struct sockaddr_in fromAddress;
    socklen_t sinSize = sizeof(struct sockaddr_in);
    char rcvDataBuf[BUFSIZE];

    /* Initialising Global Variables */
    sendfail = false;

    /* Take filename from user */
    char filename[30];
    cout << "Enter the Filename to be send or Exit: ";
    cin >> filename;

    /* Exit Condition */
    if (!strcmp(filename, "Exit") || !strcmp(filename, "Bye"))
        return 0;

    /* Start time for sending the file */
    struct timeval start;
    gettimeofday(&start, 0);

    /* Check if file exist */
    if (access(filename, F_OK) == 0)
    {
        /* Send Filename to Server */
        if (sendto(sendSocket, filename, sizeof(filename), 0, (struct sockaddr *)&sendSockAddressInfo, sizeof(struct sockaddr_in)) < 0)
        {
            cout << "Client: Error Sending Filename from Server";
            close(sendSocket);
            exit(EXIT_FAILURE);
        }

        /* Information of File */
        struct stat st;
        stat(filename, &st);
        long long int filesize = st.st_size, total_frames = 0;
        if (filesize % BUFSIZE == 0)
            total_frames = filesize / BUFSIZE;
        else
            total_frames = filesize / BUFSIZE + 1;
        cout << "File Size: " << filesize << "\tTotal Number of Packets: " << total_frames << "\n";

        /* Send Total Number of frames to Server and Recieve ACK */
        /* Initialising Variables */
        long long int ack_number = 0;
        for (int i = 0; i < MAXRETRANS && ack_number != total_frames; i++)
        {
            memset(&fromAddress, 0, sizeof(struct sockaddr_in));
            sendto(sendSocket, &total_frames, sizeof(total_frames), 0, (struct sockaddr *)&sendSockAddressInfo, sizeof(struct sockaddr_in));
            recvfrom(recieveSocket, &ack_number, sizeof(ack_number), 0, (struct sockaddr *)&fromAddress, &sinSize);
        }
        /* If timeout, Go for next try */
        if (ack_number != total_frames)
        {
            cout << "TimedOut while sending Number of frames to Server!!";
            sendfail = true;
            return 0;
        }

        /* Creating Packets for given file */
        file_packets.resize(total_frames);
        FILE *fptr = fopen(filename, "rb");
        for (int i = 0; i < total_frames; i++)
        {
            file_packets[i].SeqNum = i + 1;
            file_packets[i].length = fread(file_packets[i].data, 1, BUFSIZE, fptr);
            file_packets[i].ACK = false;
        }
        fclose(fptr);

        /* Setting Threads for Sending Frames */
        thread test[NUM_THREADS];
        int thread_id[NUM_THREADS];
        for (int i = 0; i < NUM_THREADS; i++)
        {
            thread_id[i] = i;
            test[i] = thread(&thread_function, thread_id[i], sendSocket, &sendSockAddressInfo);
        }

        /* Main thread collecting ACKs */
        int recvACK = 0;
        while (recvACK != total_frames && !sendfail)
        {
            /* Initialising Variables */
            ack_number = 0;
            memset(&fromAddress, 0, sizeof(struct sockaddr_in));
            recvfrom(recieveSocket, &ack_number, sizeof(ack_number), 0, (struct sockaddr *)&fromAddress, &sinSize);
            if (!file_packets[ack_number - 1].ACK)
            {
                file_packets[ack_number - 1].ACK = true;
                recvACK++;
                // cout << "recv ack: " << recvACK << "\n";
            }
        }
        if (!sendfail)
        {
            /* End time for sending the file */
            struct timeval end;
            gettimeofday(&end, 0);
            long seconds = end.tv_sec - start.tv_sec;
            long microseconds = end.tv_usec - start.tv_usec;
            double elapsed = seconds + microseconds * 1e-6;
            printf("Time Taken to send the File : %fs\n", elapsed);
        }
        sendfail = true;
        cout << "Waiting for All threads to Exit\n";
        /* Wait for all threads to exit */
        for (int i = 0; i < NUM_THREADS; i++)
            test[i].join();
    }
    else
    {
        cout << "Error: File Doesn't Exist\n";
    }
    /* Releasing Memory Allocation to vector */
    file_packets.resize(0);
    file_packets.shrink_to_fit();
    close(sendSocket);
    close(recieveSocket);
    exit(EXIT_SUCCESS);
}