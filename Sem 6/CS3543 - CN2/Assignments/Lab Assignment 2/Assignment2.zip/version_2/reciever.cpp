#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/time.h>
#define BUFSIZE 4096
#define NUM_THREADS 8
#define TIMEOUT 500000
#define MAXRETRANS 200
#define WINDOWSIZE 10
using namespace std;
using namespace std::chrono;

/* Packet Structure */
struct Packet
{
    int SeqNum;
    int length;
    bool SYN;
    bool ACK;
    long long int exp_recv_time;
    char data[BUFSIZE];
};

/* Main Function */
int main(int argc, char **argv)
{
    /* Check for Appropriate Command line arguments */
    if (argc != 4)
    {
        printf("Reciever: Usage --> ./[%s] [Recieve Port Number] [Send IP Address] [Send Port Number] \n", argv[0]);
        exit(EXIT_FAILURE);
    }

    /* Send Socket Address Info */
    struct sockaddr_in sendSockAddressInfo;
    memset(&sendSockAddressInfo, 0, sizeof(sendSockAddressInfo));
    sendSockAddressInfo.sin_family = AF_INET;
    sendSockAddressInfo.sin_port = htons(atoi(argv[3]));
    sendSockAddressInfo.sin_addr.s_addr = inet_addr(argv[2]);

    /* Recieve Socket Address Info */
    struct sockaddr_in recieveSockAddressInfo;
    memset(&recieveSockAddressInfo, 0, sizeof(recieveSockAddressInfo));
    recieveSockAddressInfo.sin_family = AF_INET;
    recieveSockAddressInfo.sin_port = htons(atoi(argv[1]));
    recieveSockAddressInfo.sin_addr.s_addr = INADDR_ANY;

    /* Create Send Socket */
    int sendSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (!sendSocket)
    {
        cout << "Error creating send socket" << endl;
        exit(EXIT_FAILURE);
    }

    /* Create Recieve Socket */
    int recieveSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (!recieveSocket)
    {
        cout << "Error creating recieve socket" << endl;
        exit(EXIT_FAILURE);
    }

    /* Binding Recieve Socket */
    int ret = bind(recieveSocket, (struct sockaddr *)&recieveSockAddressInfo, sizeof(struct sockaddr));
    if (ret < 0)
    {
        cout << "Error binding recieve socket" << endl;
        close(recieveSocket);
        exit(EXIT_FAILURE);
    }

    /* Required Variables of to store from Address */
    struct sockaddr_in fromAddress;
    socklen_t sinSize = sizeof(struct sockaddr_in);
    char rcvDataBuf[BUFSIZE];

    /* Server Starting to Listen */

    cout << "Server: Waiting for client to connect\n";

    /* Recieving Filename from Client */
    /* Initialising Variables */
    memset(&fromAddress, 0, sizeof(struct sockaddr_in));
    memset(&rcvDataBuf, 0, BUFSIZE);
    if (recvfrom(recieveSocket, &rcvDataBuf, BUFSIZE, 0, (struct sockaddr *)&fromAddress, &sinSize) < 0)
    {
        cout << "Server: Error Recieving Filename from Client";
        close(recieveSocket);
        exit(EXIT_FAILURE);
    }
    char *filename = rcvDataBuf;
    cout << "The Filename Recieved from Client: " << filename << "\n";

    /* Recieving Total Number of Frames to be Recieved */
    /* Initialising Variables */
    long long int total_frames = 0;
    while (total_frames <= 0)
    {
        recvfrom(recieveSocket, &total_frames, sizeof(total_frames), 0, (struct sockaddr *)&fromAddress, &sinSize);
        sendto(sendSocket, &total_frames, sizeof(total_frames), 0, (struct sockaddr *)&sendSockAddressInfo, sizeof(struct sockaddr));
    }
    cout << "Total Number of Frames to be recieved from Client: " << total_frames << "\n";

    /* Required Variabled for recieving packets */
    struct Packet pack = {0, 0, "0"};
    long long int rcvBytes = 0, rec_frames = 0;
    vector<Packet> file_packets(total_frames, pack);

    /* Recieve All frames and send ACK subsequently */
    while (rec_frames != total_frames)
    {
        memset(&pack, 0, sizeof(pack));
        recvfrom(recieveSocket, &pack, sizeof(pack), 0, (struct sockaddr *)&fromAddress, &sinSize);                                 //Recieve the frame
        sendto(sendSocket, &pack.SeqNum, sizeof(pack.SeqNum), 0, (struct sockaddr *)&sendSockAddressInfo, sizeof(struct sockaddr)); //Send the ack

        /* If the frame is not repeated Frame */
        if (file_packets[pack.SeqNum - 1].SeqNum == 0)
        {
            rec_frames++;
            file_packets[pack.SeqNum - 1] = pack;
            // cout << "Frame.ID: " << frame.ID << "\t Frame.length: " << frame.length << "\n";
            // cout << "Received Frames: " << rec_frames << "\n";
            rcvBytes += pack.length;
        }
    }
    struct Packet final_frame;
    final_frame.SeqNum = total_frames + 1;
    while (pack.SeqNum != final_frame.SeqNum)
    {
        memset(&pack, 0, sizeof(pack));
        recvfrom(recieveSocket, &pack, sizeof(pack), 0, (struct sockaddr *)&fromAddress, &sinSize);                                 //Recieve the frame
        sendto(sendSocket, &pack.SeqNum, sizeof(pack.SeqNum), 0, (struct sockaddr *)&sendSockAddressInfo, sizeof(struct sockaddr)); //Send the ack
    }

    cout << "Total Bytes Recieved: " << rcvBytes << "\n";

    /* Writing Recieved Frames into file */
    FILE *fptr = fopen(filename, "wb");
    for (int i = 0; i < total_frames; i++)
    {
        fwrite(file_packets[i].data, 1, file_packets[i].length, fptr);
    }
    fclose(fptr);

    /* Releasing Memory Allocation to vector */
    file_packets.resize(0);
    file_packets.shrink_to_fit();
    close(sendSocket);
    close(recieveSocket);
    exit(EXIT_SUCCESS);
}