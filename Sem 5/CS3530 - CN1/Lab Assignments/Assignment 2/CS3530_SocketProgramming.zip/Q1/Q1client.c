#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define BUFSIZE 1024

int main(int argc, char **argv) {

	if (argc != 4) {
		perror("<Server Hostname/Address> <Server Port> <Echo Word>");
		exit(-1);
	}

	// Reconfiguring arguments
	char *hostName = argv[1];		// Get HostName or IPv4/v6 Address
	char *portName = argv[2];		// Get PortName or Port Number
	char *echoString = argv[3];		// Get messaged to be echoed
	
    // struct sockaddr *address;
    struct sockaddr_in *saIn4;
    struct sockaddr_in6 *saIn6;
    char addrString[INET6_ADDRSTRLEN];
    memset(addrString, 0, sizeof(addrString));

    struct addrinfo hints;			// Give initial hints to resolver
	struct addrinfo *result, *rp;		// Result will be stored here

    // Prepare the hints for resolver
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;		// IPv4 or v6
	hints.ai_socktype = SOCK_STREAM;	// Hardcoded TCP as dummy
	hints.ai_protocol = IPPROTO_TCP;	// Hardcoded TCP as dummy
	hints.ai_flags = AI_CANONNAME;		// I want canonical name!!

	// Get address(es) associated with the specified name/service
	// Modify servAddr contents to reference linked list of addresses
	int s = getaddrinfo(hostName, portName, &hints, &result);
	if (s != 0) {
		perror("getaddrinfo() failed");
		exit(s);
	}

	// Display returned addresses3.1 Mapping Names to Numbers
	// We don't use portName because no need of resolving service
	int sockfd;
    for (rp = result; rp != NULL; rp = rp->ai_next) {
		switch (rp->ai_family) {
		case AF_INET:	// If IPv4 is Detected
			saIn4 = (struct sockaddr_in *) rp->ai_addr;
			inet_ntop(rp->ai_family, &saIn4->sin_addr.s_addr, addrString, sizeof(addrString));
            sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
			if (sockfd == -1)
                continue;
			if(connect(sockfd, rp->ai_addr, rp->ai_addrlen) !=-1) {
				printf("Given IP protocol is: IPv4\n");
				break;
			}
			break;

		case AF_INET6:	// If IPv6 is Detected
			saIn6 = (struct sockaddr_in6 *) rp->ai_addr;
			inet_ntop(rp->ai_family, &saIn6->sin6_addr.s6_addr, addrString, sizeof(addrString));
			sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
			if (sockfd == -1)
                continue;
			if(connect(sockfd, rp->ai_addr, rp->ai_addrlen) !=-1) {
				printf("Given IP protocol is: IPv6\n");
				break;
			}
            break;

		default:
			printf("unknown protocol\n");
			break;
		}	
	}
	
	freeaddrinfo(result); // Free addrinfo allocated in getaddrinfo()

	// Length of echo string
	size_t echoStringLen = strlen(echoString);
	
	// Send string to server
	ssize_t sentLen = send(sockfd, echoString, echoStringLen, 0);
	if (sentLen < 0) {
		perror("send() failed");
		exit(-1);
	} else if (sentLen != echoStringLen) {
		perror("send(): sent unexpected number of bytes");
		exit(-1);
	} else {
		time_t ltime1; /* calendar time */
		ltime1 = time(NULL); /* get current cal time */
		printf("Message Sent to Server at %s is : %s\n",asctime(localtime(&ltime1)),echoString);
	}

	// Receive string from server
	unsigned int totalRecvLen = 0;

	time_t ltime2; /* calendar time */
	ltime2 = time(NULL); /* get current cal time */
	printf("Echo Message Received from Server at %s is : ",asctime(localtime(&ltime2)));
	while (totalRecvLen < echoStringLen) {
		char buffer[BUFSIZE];
		memset(buffer, 0, BUFSIZE);
		ssize_t recvLen = recv(sockfd, buffer, BUFSIZE - 1, 0);
		if (recvLen < 0) {
			perror("recv() failed");
			exit(-1);
		} else if (recvLen == 0) {
			perror("recv() connection closed prematurely");
			exit(-1);
		}
	
		totalRecvLen += recvLen;
		buffer[recvLen] = '\n';
		fputs(buffer, stdout);	
	}
	
	close(sockfd);
	exit(0);
}