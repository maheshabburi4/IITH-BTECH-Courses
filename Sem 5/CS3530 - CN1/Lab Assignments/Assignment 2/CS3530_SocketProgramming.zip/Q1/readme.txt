Compiling:
    gcc Q1client.c -o q1cli
    gcc Q1server.c -o q1ser

Running:
    Server:
        ./q1ser 1234
    Here
        1234 is the port number

    Client:
        ./q3cli 127.0.0.1 1234 Hello
                    (or)
        ./q3cli localhost 1234 Hello
    Here
        127.0.0.1 is the IPv4 address of local host
        localhost is the host name to be called using IPv4 protocol
        1234 is the listening port(same as given for server)
        Hello is the messaged to be echoed