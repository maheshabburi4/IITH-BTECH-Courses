Compiling:
    gcc Q3client.c -o q3cli
    gcc Q3server.c -o q3ser

Running:
    Server:
        ./q3ser 1234
    Here
        1234 is the port number

    Client:
        ./q3cli 127.0.0.1 1234 Hello
                    (or)
        ./q3cli localhost 1234 Hello
                    (or)
        ./q3cli ip6-localhost 1234 Hello
                    (or)
        ./q3cli ::1 1234 Hello
                    (or)
        ./q3cli ::ffff:127.0.0.1 1234 Hello
    Here
        127.0.0.1 is the IPv4 address of local host
        localhost is the host name to be called using IPv4 protocol
        ip6-localhost is th hostname to be called using IPv6 protocol
        ::1 or ::ffff:127.0.0.1 can be used to call local host using IPv6 protocol 
        1234 is the listening port(same as given for server)
        Hello is the messaged to be echoed