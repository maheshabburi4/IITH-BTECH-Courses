#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <atomic>
#include <bits/stdc++.h>

#define BUFSIZE 1024

std::atomic<bool> endProg (false);

// Receive Data from server
int recieve_data_from_server(char * buffer, int client_socket)
 {
	memset(buffer, 0, BUFSIZE);
	ssize_t recvLen = recv(client_socket, buffer, BUFSIZE - 1, 0);
	if (recvLen < 0) {
		perror("recv() failed");
		exit(-1);
	}
	buffer[recvLen] = '\0';
    return recvLen;
}

// Send Data to server
void send_data_to_server(char * buffer, int client_socket, ssize_t len){
	
    ssize_t sentLen = send(client_socket, buffer, len, 0);
	if (sentLen < 0) {
		perror("send() failed");
		exit(-1);
	}
    else if (sentLen != len){
        perror("send(): sent unexpected number of bytes");
		exit(-1);
    }
	memset(buffer, 0, BUFSIZE);
}


void * data_reciving_thread (void * sockID){
    int client_socket = *((int *) sockID);
    int temp;
    while(1){
        char buffer[BUFSIZE];
        temp = recieve_data_from_server(buffer, client_socket);
        if(temp == 0){
            printf("\nServer down\n>>");
            fflush(stdout);
            endProg = true;
            return NULL;
        }
        printf("\n%s\n",buffer);
        printf(">> ");
        fflush(stdout);
    }
    return NULL;
}

int main() {
    /*Default : Local host */
    char servIP[100] = "127.0.0.1"; 
    in_port_t servPort = 8002;
	
    printf("Enter: <Server Address>\n");
    scanf("%s", servIP);
    printf("Enter: <Port>\n");
    scanf("%hu", &servPort);

	// Create a socket
	int client_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (client_socket < 0) {
		perror("socket() failed");
		exit(-1);
	}

    struct sockaddr_in servAddr;
   	memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
	int err = inet_pton(AF_INET, servIP, &servAddr.sin_addr.s_addr);
	if (err <= 0) {
		perror("inet_pton() failed");
		exit(-1);
	}
    servAddr.sin_port = htons(servPort);

	// Connect to server
	if (connect(client_socket, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0) {
		perror("connect() failed");
		exit(-1);
	}

    printf("Enter: <User_ID>\n");
    ssize_t length;
    char id[BUFSIZE] = "User@name";
    length = strlen(id);
    /*Updating user in server*/
    send_data_to_server(id, client_socket, length);
    
    scanf("%s",id);
    length = strlen(id);
    /*Updating user name in server*/
    send_data_to_server(id, client_socket, length);

    printf("\n*********************************************************\n");
    printf("*\t You are connected to server @%s\t*" , servIP);
    printf("\n*********************************************************\n\n");
    printf("List of Commands\n");
    printf("[u|U] - to get list of all clients connected to Server\n");
    printf("[s|S] - Send msg to single client\n\tformat: s <ID_Number> <Msg>\n");
    printf("[b|B] - Broadcast msg to all other clients\n\tformat: b <Msg>\n");
    printf("[g|G] - Get your ID\n");
    printf("[e|E] - for exiting... \n");

    printf("Enjoy our Services\n");
    
    /*Reaciving is seperate from main thread*/
    pthread_t thread;
    pthread_create(&thread, NULL, data_reciving_thread, (void *) &client_socket );
    /*main thread for Sending the commands*/
    printf(">> ");
    while(1)
     {
        size_t len;
        char input[BUFSIZE];
        char inp;
        scanf("%c",&inp);
        /*If Server is down*/
        if (endProg) break;

        switch (inp) {
            case 'u':
            case 'U':
                //printf("Users data\n");
                strncpy(input, "Users_data", sizeof(input));
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
                break;
            
            case 's':
            case 'S':
                //printf ("Sending data\n");
                strncpy(input, "Send", sizeof(input));
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
            
                scanf("%s",input);
                len = strlen(input);
                send_data_to_server(input, client_socket, len);

                scanf("%[^\n]s",input);
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
                
                break;
            
            case 'b':
            case 'B':
                //printf ("Broadcast\n");
                strncpy(input, "Broadcast", sizeof(input));
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
                
                scanf("%[^\n]s",input);
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
                
                break;
            
            case 'g':
            case 'G':
                //printf ("Get ID\n");
                strncpy(input, "Get_ID", sizeof(input));
                len = strlen(input);
                send_data_to_server(input, client_socket, len);
                break;
            
            case 'e':
            case 'E':
                printf("Exiting... \n");
                fflush(stdout);
                return 0;
        }
        printf(">> ");
    }
}