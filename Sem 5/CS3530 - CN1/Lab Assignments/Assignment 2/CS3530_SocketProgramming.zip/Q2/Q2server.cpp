#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <memory>
#include <stdexcept>
#include <cstdio>
#include <iostream>
#include <array>

#define BUFSIZE 1024

static const int MAXPENDING = 5; // Maximum outstanding connection requests
struct client{
    int index;
    int clntSock;
    struct sockaddr_in clntAddr;
    socklen_t clntAddrLen;
};

pthread_t thread[1024];
char name[1024][100];
struct client Client[1024];
int client_Count = 0;

/*Function for data recieving*/
void recieve_data_from_client(char * buffer, struct client* cInfo){
    memset(buffer, 0, BUFSIZE);
    ssize_t recvLen = recv(cInfo->clntSock, buffer, BUFSIZE - 1, 0);
    if (recvLen < 0) {
        perror("recv() failed");
        exit(-1);
    }
    buffer[recvLen] = '\0';
}

/*Function for data sending*/
void send_data_to_client (char * buffer, int clntSock){
    ssize_t sentLen = send(clntSock, buffer, BUFSIZE - 1, 0);
    if (sentLen < 0) {
        perror("send() failed");
        exit(-1);
    }
}
/*Seperate threads for Client process*/
void* host(void * c){
    struct client* cInfo = (struct client*) c;
    printf("Client %d connected.\n",cInfo -> index + 1);
    while(1){
        char buffer[BUFSIZE];
        recieve_data_from_client(buffer, cInfo);

        if(strcmp(buffer,"Users_data") == 0){
            int l = 0;
            for(int i = 0 ; i < client_Count ; i ++)
                l += snprintf(buffer + l, BUFSIZE - 1, "Client %d: %s\n", i + 1, name[i]);
            send_data_to_client(buffer, cInfo -> clntSock);
        }
        else if(strcmp(buffer,"Send") == 0){
            recieve_data_from_client(buffer, cInfo);
            int temp = atoi(buffer) - 1;
            recieve_data_from_client(buffer, cInfo);
            printf("Message transfer from %s > %s\n",name[cInfo -> index], name[temp]);
            char tmp[BUFSIZE];
            int l = 0;
            l = snprintf(tmp + l, BUFSIZE - 1, "Msg from Client %d: %s -> ", cInfo -> index + 1, name[cInfo -> index]);
            l = snprintf(tmp + l, BUFSIZE - 1, "%s\n", buffer);
            send_data_to_client(tmp, Client[temp].clntSock);
            memset(tmp, 0, BUFSIZE);
            memset(buffer, 0, BUFSIZE);
        }
        else if(strcmp(buffer,"Broadcast") == 0){
            recieve_data_from_client(buffer, cInfo);
            printf("Broadcast from %s \n", name[cInfo->index]);
            char temp[BUFSIZE];
            int l = 0;
            l = snprintf(temp + l, BUFSIZE - 1, "Broadcast Msg from Client %d: %s -> ", cInfo -> index + 1, name[cInfo -> index]);
            l = snprintf(temp + l, BUFSIZE - 1, "%s\n", buffer);
            for (int i = 0; i < client_Count; i++)
                if (i != cInfo->index)
                    send_data_to_client(temp, Client[i].clntSock);
            memset(temp, 0, BUFSIZE);
            memset(buffer, 0, BUFSIZE);       
        }

        else if(strcmp(buffer,"User@name") == 0){
            recieve_data_from_client(buffer, cInfo);
            strcpy(name[cInfo -> index],buffer);
            printf("Username Registered: %s\n",name[cInfo -> index]);
            fflush(stdout);
        }
        else if(strcmp(buffer,"Get_ID") == 0){
            printf("Requesting User_ID by %s\n",name[cInfo -> index]);
            char temp[BUFSIZE];
            int l = 0;
            l = snprintf(temp + l, BUFSIZE - 1, "Your ID is : %d ", cInfo -> index + 1);

            send_data_to_client(temp, cInfo->clntSock);
            fflush(stdout);
        }
    }
    return NULL;
}

int main(){
    
    char servIP[100] = "127.0.0.1"; 
    in_port_t servPort = 8002;
    printf("Enter: <Server Address>\n");
    scanf("%s", servIP);
    printf("Enter: <Port>\n");
    scanf("%hu", &servPort);

    // create socket for incoming connections
    int servSock;
    if ((servSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        perror("socket() failed");
        exit(-1);
    }

    // Set local parameters
    struct sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(servPort);


    // Bind to the local address
    if (bind(servSock, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0) {
        perror("bind() failed");
        exit(-1);
    }

    // Listen to the client
    if (listen(servSock, MAXPENDING) < 0) {
        perror("listen() failed");
        exit(-1);
    }
    printf("Server hosted on IP: %s\nWaiting for client on Port: %hu...\n", servIP, servPort);

    while(1){
        /*Accepting Clients*/
        Client[client_Count].clntSock = accept(servSock, (struct sockaddr*) &Client[client_Count].clntAddr, &Client[client_Count].clntAddrLen);
        if(Client[client_Count].clntSock < 0){
            perror("accept() failed");
            exit(-1);
        }

        Client[client_Count].index = client_Count;
        /*Creating threads for each client*/
        pthread_create(&thread[client_Count], NULL, host, (void *) &Client[client_Count]);
        client_Count ++;
    }

    /*Waiting for all threads to join*/
    for(int i = 0 ; i < client_Count ; i ++)
        pthread_join(thread[i],NULL);

    return 0;
}