Compiling:
    $ g++ Q2server.cpp -o server -pthread
    $ g++ Q2client.cpp -o client -pthread
    
Running:
    Server:
        ./server

    Client:
        ./client