Execution:
Download the zip file CS18BTECH11001.zip
Unzip the zip file
Enter into the unzipped folder
Open terminal in the present directory
The report includes the answers for 1st, 2nd question and some proofs for 3rd and 4th questions
execute $jupyter notebook Command
Browse to the present directory
    foml_3.ipynb is the solution for 3rd question
    foml_4.ipynb is the solution for 4th question
All the required data for 3rd and 4th question are written in the .ipynb file