Precompilation:
    Installing pip3:
        sudo apt update
        sudo apt install python3-pip
    Install Numpy:
        pip3 install numpy
    Install pandas
        pip3 install pandas
    Install xgboost
        pip3 install xgboost
    Install sklearn
        pip3 install sklearn

Compiling and Execution:
    python3 CS18BTECH11001_1.py
    python3 CS18BTECH11001_1.py

Output file:
    test_output.csv
        |   Source code name     Private Score   Public Score
        |-  CS18BTECH11001_1.py  0.93427         0.95305
        |-  CS18BTECH11001_2.py  0.94366         0.93896

PS: I didn't know that we have to specify our 2 best trained models for final score. 
    Please consider these 2 Scores and can be checked in my leaderboard
    Ignore the warnings occured while execution