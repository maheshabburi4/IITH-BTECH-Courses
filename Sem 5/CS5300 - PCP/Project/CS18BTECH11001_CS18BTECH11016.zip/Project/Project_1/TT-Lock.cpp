#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;

map<unsigned long long int, int> mp;
vector <vector<int>> atom;
vector<unsigned long long int> enter_times,exit_times;
FILE *output,*input,*co,*ent_t,*ext_t;
int n,k;

void lok(int id)//method to implement lock
{
  for(int i=n+id-1;i>1;i/=2)//tree based synchronization primitive
  {
    atom[(i/2)-1][i%2]=1;
    atom[(i/2)-1][2]=i%2;
    while(atom[(i/2)-1][1-(i%2)]&&(atom[(i/2)-1][2]==i%2));
  }
  mp[clock()]=id;//adding the thread into the priority queue
  for(int i=n+id-1;i>1;i/=2)
    atom[(i/2)-1][i%2]=0;
  while(mp.begin()->second!=id);//wait until you are the thread who requested 1st in the present waiting queue
}

void unlok(int id)//method to implement unlock
{
  fprintf(co,"The thread-%d requested to entry for CS at %llu\n",id,mp.begin()->first);
  mp.erase(mp.begin());//removing the thread from the queue
}

void testalgo(int id)//function to test the performance of the lock algorithm
{
  clock_t t1,t2;
  char const *c;
  time_t req,ent,ex,rex;
  tm *ltm;
  for(int i=1;i<=k;i++)
  {
    if(i==1)
     c="st";
    else if(i==2)
     c="nd";
    else if(i==3)
     c="rd";
    else
     c="th";
    req=time(0);//request to enter CS
    ltm=localtime(&req);
    t1=clock();
    fprintf(output,"%d%s CS Entry Request at %d:%d:%d by thread %d\n",i,c,5+ltm->tm_hour,30+ltm->tm_min,ltm->tm_sec,id);
    lok(id);//acquired lock
    ent=time(0);//entered CS
    ltm=localtime(&ent);
    t1=clock()-t1;//CSEnterTime
    fprintf(output,"%d%s CS Entry at %d:%d:%d by thread %d\n",i,c,5+ltm->tm_hour,30+ltm->tm_min,ltm->tm_sec,id);
    enter_times[id-1]+=t1;
    usleep(pow(10,6));
    rex=time(0);//request to exit CS
    ltm=localtime(&rex);
    t2=clock();
    fprintf(output,"%d%s CS Exit Request at %d:%d:%d by thread %d\n",i,c,5+ltm->tm_hour,30+ltm->tm_min,ltm->tm_sec,id);
    unlok(id);//releasing the lock
    ex=time(0);//exiting the CS
    ltm=localtime(&ex);
    t2=clock()-t2;//CSExitTime
    fprintf(output,"%d%s CS Exit at %d:%d:%d by thread %d\n",i,c,5+ltm->tm_hour,30+ltm->tm_min,ltm->tm_sec,id);
    exit_times[id-1]+=t2;
    usleep(pow(10,6));
  }
}

void initialization()//methos to initialize the data variables
{
  input=fopen("inp-params.txt","r");//reading input from file
  fscanf(input,"%d",&n);
  fscanf(input,"%d",&k);
  output=fopen("output.txt","w");//to output the activity of the threads with time-stamp
  co=fopen("clock_order.txt","w");//to output the CS request order of the threads based on the time-stamp
  ent_t=fopen("Avg-enter_times.txt","w");//to output average time taken to enter CS by each thread
  ext_t=fopen("Avg-exit_times.txt","w");//to output average time taken to exit CS by each thread
  enter_times.resize(n);
  exit_times.resize(n);
  for(int i=0;i<n;i++)
  {
    enter_times[i]=0;
    exit_times[i]=0;
  }
  atom.resize(n-1);
  for(int i=0;i<n-1;i++)
  {
    atom[i].resize(3);
    atom[i][0]=atom[i][1]=0;
  }
}

int main()//driver function
{
  initialization();
  unsigned long long ent,ext;
  ent=ext=0;
  thread test_thread[n];
  int argument[n],i;
  for(i=0;i<n;i++)
  {
    argument[i]=i+1;
    test_thread[i]=thread(testalgo,argument[i]);//initialization of the threads
  }
  for(int i=0;i<n;i++)
   test_thread[i].join();//main thread waiting for the other n threads to complete their tasks
  fclose(co);
  for(i=1;i<=n;i++)
  {
    fprintf(ent_t,"The average CS entry-time of thread-%d = %lluUs\n",i,enter_times[i-1]);
  }
  for(i=0;i<n;i++)
   ent+=enter_times[i];
  fprintf(ent_t,"\nThe total average CS entry-time = %lluUs",ent/n);
  fclose(ent_t);
  for(i=1;i<=n;i++)
  {
    fprintf(ext_t,"The average CS exit-time of thread-%d = %lluUs\n",i,exit_times[i-1]);
  }
  for(i=0;i<n;i++)
   ext+=exit_times[i];
  fprintf(ext_t,"\nThe total average CS exit-time = %lluUs",ext/n);
  fclose(ext_t);
  fclose(output);//closing the output file to print the output into the output file by pushing from the buffer
  return(0);
}