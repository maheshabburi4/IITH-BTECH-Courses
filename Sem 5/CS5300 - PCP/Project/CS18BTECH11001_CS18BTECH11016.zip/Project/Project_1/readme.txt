*A file named 'inp-params.txt' should be stored in the same directory as of the
 source file(TT-Lock.cpp) to take input for the programs.
*The 'inp-params.txt' should contain values of n and k successively.
 Note:- Please do not give higher values for n and k as sleep time for threads is given as 1sec
 to interpret the activity of threads clearly.
*Now type g++ TT-Lock.cpp -pthread through the directory where the source file is stored in terminal 
 or any command line interface to compile the respective source code file.
*To execute the program, type ./a.out which outsputs bunch of files-'output.txt','Avg-enter_times.txt',
 'Avg-exit_times.txt' and 'clock_order.txt'.