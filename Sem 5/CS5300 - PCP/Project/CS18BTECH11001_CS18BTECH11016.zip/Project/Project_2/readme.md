## Compiling and Running: ##
1. Change the permission of _run.sh_ using the following command\
    ```$ chmod +rwx run.sh```
2. To run the Src code use the follwing command\
    ```$ ./run.sh```

## Input File: ##
1. The input parameters are present in the file _input_params.txt_.\
    The input file parameters are:
    > V : Number of vertices in the graph\
    > R : 0 for random \
    &nbsp;&nbsp;&nbsp;&nbsp; 1 for user input\
    > N : Number of threads\
    > M : Adjacency Matrix of size V*V if R = 1

## Output File: ##
1. _sequential\_MST_ containing edges in MST in the format (from vertex - To vertex Weight)
2. _parallel\_MST_ containing edges in MST in the format (from vertex - To vertex Weight)

## Terminal Output ##
1. Prints the number of vertices, number of threads inputted from the input file
2. The time taken by the Sequential Prim's Algorithm
3. The time taken by the Parallel Prim's Algorithm

## run.sh ##
1. Contains the script to compile and execute src code.
2. You can uncomment Correctness for checking whether the output is correct only if you are sure that there exits only one MST for the given input.