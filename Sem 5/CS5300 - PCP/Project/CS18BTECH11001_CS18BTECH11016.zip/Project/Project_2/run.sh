#!/bin/bash

# Compiling the src file with OpenMP flag
g++ -o prim Prims.cpp -fopenmp
# echo "Compiling Done Successfully"

# Executing the object file taking input from input file
./prim <input_params.txt
# echo "Execution Done Successfully"

# # Checking Correctness of parallel algorithm
# # Use only it is guarenteed that only one MST exists for the given input
# diff parallel_MST.txt sequential_MST.txt 
# echo "Correct Output for Parallel Algorithm"