#include <bits/stdc++.h>
#include <omp.h>
using namespace std;
using namespace std::chrono;

#define MAX_WEIGHT 1000             // max weight for randomised graph

// Function for picking minimum key vertex 
// from set of vertices not included in MST
// for Sequential Prim's Algorithm
int minKeySeq(vector<int> key, vector<int> visited) {
    int V = key.size();             // Fetching Number of vertices in the graph
    int min = INT_MAX;              // For minimum key value 
    int min_index;                  // vertex with minimum key value

    // Loop through all vertices
    for (int v = 0; v < V; v++) {
        // check for vertex not included in MST 
        // check for minimum key value
        if (visited[v] == 0 && key[v] < min){   
            min = key[v];   // update the min key value
            min_index = v;  // update the vertex number of min key
        }
    }

    // return the final vertex with min key value
    return min_index;
}

// Sequencial Prim's Algorithm
vector<int> primMSTSeq(vector<vector<int>> graph) {
    int V = graph.size();           // Fetching Number of Verices in the graph
    vector<int> from(V);            // To store constructed MST
    vector<int> key(V,INT_MAX);     // To pick minimum weight edge from the cut, initialising to INF = INT_MAX
    vector<int> visited(V,0);       // For vertices not included in MST, initialising all to 0 
    
    // Starting from first vertex
    key[0] = 0;         // The first picked vertex
    from[0] = -1;       // Taking first node as root of MST

    // The MST will have V vertices
    for (int count = 0; count < V - 1; count++) {
        // Pick vertex with minimum key from the set of vertices
        // not yet included in MST
        int u = minKeySeq(key, visited);

        // Add the picked vertex to the MST Set
        visited[u] = 1;

        for (int v = 0; v < V; v++) {
            // if there exists and edge between u and v
            // and if vertex v is not included in the MST yet
            // and if present key value is less than past key
            if (graph[u][v] && visited[v] == 0 && graph[u][v] < key[v]) {
                from[v] = u;                // Add edge from v to u to MST
                key[v] = graph[u][v];       // Update key value to the min distance
            }
        }
    }

    // returning the final constructed in MST
    return from;
}

// Function for picking minimum key vertex 
// from set of vertices not included in MST
// for Parallel Prim's Algorithm
int minKeyPar(vector<int> key, vector<int> visited) {
    int V = key.size();             // Fetching Number of vertices in the graph
    int min = INT_MAX;              // For minimum key value 
    int min_index;                  // vertex with minimum key value
    int i;                          // private variable for each thread

// Parallelising using openMP
// using number of threads as set in the main method
#pragma omp parallel 
    {
        int min_local = min;            // To store the local min key value 
        int index_local = min_index;    // To store the local vertex number of min key

// Parallelised for loop using openMP
// for finding local minimum key values
#pragma omp for nowait
        for (i = 0; i < V; i++) {
            // check for vertex not included in MST 
            // check for minimum key value
            if (visited[i] == 0 && key[i] < min_local) {
                min_local = key[i];     // update the local min key value
                index_local = i;        // update the local vertex number of min key
            }
        }

// Finding minimum key value of all threads
// Handling Critical Section
#pragma omp critical
        {
            // if the minimum of local thread is then global min value
            if (min_local < min) {
                min = min_local;            // Update global min key value
                min_index = index_local;    // Update the global vertex number of min key
            }
        }
    }

    // return the final vertex with min key value
    return min_index;
}

// Parallelised Prim's Algorithm
vector<int> primMSTPar(vector<vector<int>> graph) {
    int V = graph.size();           // Fetching Number of Verices in the graph
    vector<int> from(V);            // To store constructed MST
    vector<int> key(V,INT_MAX);     // To pick minimum weight edge from the cut, initialising to INF = INT_MAX
    vector<int> visited(V,0);       // For vertices not included in MST, initialising all to 0 
    
    // Starting from first vertex
    key[0] = 0;         // The first picked vertex
    from[0] = -1;       // Taking first node as root of MST

    // The MST will have V vertices
    for (int count = 0; count < V - 1; count++){
        // Pick vertex with minimum key from the set of vertices
        // not yet included in MST
        int u = minKeyPar(key, visited);
        
        // Add the picked vertex to the MST Set
        visited[u] = 1;

        int v;          // private variable for each thread

// Parallelised for loop using openMP
#pragma omp parallel for schedule(static)
        for (v = 0; v < V; v++) {
            // if there exists and edge between u and v
            // and if vertex v is not included in the MST yet
            // and if present key value is less than past key
            if (graph[u][v] && visited[v] == 0 && graph[u][v] < key[v]) {
                from[v] = u;                // Add edge from v to u to MST
                key[v] = graph[u][v];       // Update key value to the min distance
            }
        }
    }

    // returning the final constructed in MST
    return from;
}

// Printing the Minimum Spanning Tree
int printMST(FILE *out, vector<int> from, vector<vector<int>> graph){
    int V = graph.size();               // Fetching number of vertices in the graph
    int min_spanning_weight = 0;
    fprintf(out, "%-15s - %-5s %-15s %-15s\n","From Vertex"," ","To Vertex"," Weight");
    for (int i = 1; i < V; i++){
        min_spanning_weight += graph[i][from[i]];
        fprintf(out, "%-15d - %-5s %-15d  %-15d \n", from[i], " ", i, graph[i][from[i]]);
    }
    return min_spanning_weight;
}

// The main Method
int main(){
    // Number of vertices
    int V;
    // cout<<"Enter number of vertices: ";
    cin>>V;
    cout<<"Number of Vertices: "<<V<<"\n";

    // Input for randomised graph or input from user
    int random;
    // cout<<"Enter 0 for random graph and 1 for user input graph"
    cin>>random;

    // Number of threads
    int N;
    // cout<<"Enter number of threads: ";
    cin>>N;
    cout<<"Number of threads: "<<N<<"\n";
    omp_set_num_threads(N);

    // Adjacency Matrix
    vector<vector<int>> adj(V,vector<int>(V,0));
    switch (random) {
        // Random Adjacent Matrix
        case 0:
            // Making edges with random weights
            for(int i = 0; i < V; i++) {
                for(int j = 0; j < V; j++) {
                    adj[i][j] = rand()%(MAX_WEIGHT+1);
                }
            }    
            // Ensuring No self loops
            for(int i = 0; i < V; i++)
                adj[i][i] = 0;
            // Ensuring Undirectedness - Symmetric adjacent matrix
            for(int i = 0; i < V; i++) {
                for(int j = 0; j < V; j++) {
                    adj[i][j] = adj[j][i];
                }
            }
            break;
        
        // User Input Adjacent Matrix
        case 1:

            for(int i = 0; i < V; i++){
                for(int j = 0; j < V; j++){
                    cin>>adj[i][j];
                }
            }
            break;

        // Handling invalid inputs
        default:
            cout<<"Input parameters are wrong\n Please check input_params.txt";
            break;
    }

    // Sequential Prim's Algorithm
    time_point<system_clock> start1 = system_clock::now();  
    vector<int> seq_from = primMSTSeq(adj);
    time_point<system_clock> end1 = system_clock::now(); 
    
    // Printing sequential output to the file
    FILE *seq_out = fopen("sequential_MST.txt","w");
    int seq_wei = printMST(seq_out,seq_from,adj);
    printf("The Weight of minimum Spanning tree in Sequential Execution: %d\n", seq_wei);
    printf("Time for Sequential Prim Algorithm = %ld us\n", duration_cast<microseconds>(end1 - start1).count());

    // Parallel Prim's Algorithm 
    time_point<system_clock> start2 = system_clock::now();  
    vector<int> par_from = primMSTPar(adj);
    time_point<system_clock> end2 = system_clock::now(); 

    // Printing parallel output to the file
    FILE *par_out = fopen("parallel_MST.txt","w");
    int par_wei = printMST(par_out,par_from,adj);
    printf("The Weight of minimum Spanning tree in Parallel Execution: %d\n", par_wei);
    printf("Time for Parallel Prim Algorithm = %ld us\n", duration_cast<microseconds>(end2 - start2).count());
    return 0;
}