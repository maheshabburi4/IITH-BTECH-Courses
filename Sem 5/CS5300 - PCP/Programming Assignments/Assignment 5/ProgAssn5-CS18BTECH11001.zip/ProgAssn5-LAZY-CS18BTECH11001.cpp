#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;

atomic_llong time_taken;

// Structure for Node
class Node {
    public:
        int key;            // Data value storage
        bool marked;
        Node* next;         // Linked List pointer
    
    private:
        mutex mtx;          // Mutex Lock to ensure one one thread access node at a time

    public:
        // Contructor initialisation of Node
        Node(int item){     
            key = item;
            marked = false;
            next = NULL;
        }

        // Lock method of Node to apply locking to Node Position
        void lock(){        
            mtx.lock();
        }
        
        // Unlock method of Node to apply Unlocking to Node position
        void unlock(){      
            mtx.unlock();
        }
};

class Lazy{
    // Data Variables of the set
    Node* head = NULL;
    Node* tail = NULL;

    // Member functions
    public:
        // Constructor for initialising Data Variables of Set
        Lazy(){                   
            head = new Node(INT_MIN);
            tail = new Node(INT_MAX);
            head->next = tail;
        }

        // The add(item) Method adds x to the set, 
        // returning true if, and only if x was not already there.
        bool add(int item) {
            int key = item;
            while(true) {
                Node* pred = head;
                Node* curr = pred->next;
                while(curr->key < key) {
                    pred = curr;
                    curr = curr->next;
                }
                pred->lock();
                curr->lock();
                if(validate(pred,curr)) {
                    if(curr->key == key) {
                        curr->unlock();
                        pred->unlock();
                        return false;
                    } else {
                        Node* node = new Node(item);
                        node->next = curr;
                        pred->next = node;
                        curr->unlock();
                        pred->unlock();
                        return true;
                    }
                }
                curr->unlock();
                pred->unlock();
            }
        }

        // The remove(x) method removes x from the set, 
        // returning true if, and only if x was there.
        bool remove(int item) {
            int key = item;
            while(true) {
                Node* pred = head;
                Node* curr = pred->next;
                while(curr->key < key) {
                    pred = curr;
                    curr = curr->next;
                }
                pred->lock();
                curr->lock();
                if(validate(pred,curr)) {
                    if(curr->key != key) {
                        curr->unlock();
                        pred->unlock();
                        return false;
                    } else {
                        curr->marked = true;
                        pred->next = curr->next;
                        curr->unlock();
                        pred->unlock();
                        return true;
                    }
                }
                curr->unlock();
                pred->unlock();
            }
        }

        // The contains(x) returns true if, and only if the set contains x.
        bool contains(int item) {
            int key = item;
            Node* curr = head;
            while(curr->key < key)
                curr = curr->next;
            return curr->key == key && !curr->marked;
        }

    private:
        // Private function to be used by above public functions
        bool validate(Node* pred, Node* curr) {
            return !pred->marked && !curr->marked && pred->next == curr;
        }
};

void test(FILE* out, int N, int K, int thread_id, Lazy* lazy_syn, int lam1) {
    int id = thread_id;             // Fetching Thread id
    for(int i = 1; i <= K; i++) {
        int op = rand()%3;          // Choosing option randomly
        int number = rand()%(K*N);  // choose a number randomly to per form the operation
        int result;
        string oper, res;
        time_point<system_clock> start = system_clock::now();
        switch (op) {
        case 0:
            result = lazy_syn->add(number);
            oper = "add";
            break;
        
        case 1:
            result = lazy_syn->remove(number);
            oper = "remove";
            break;
        
        case 2:
            result = lazy_syn->contains(number);
            oper = "contains";
            break;
        
        default:
            break;
        }  
        time_point<system_clock> end = system_clock::now();
        time_t endTime = system_clock::to_time_t(end);
        tm *ltm = localtime(&endTime);
        time_taken += duration_cast<nanoseconds>(end - start).count();
        if(result) 
            res = "True"; 
        else 
            res = "False"; 
        fprintf(out, "Thread %d performs %s with number %d in round %d with results %s at %d:%d:%d\n",thread_id,oper.c_str(),number,i,res.c_str(),ltm->tm_hour,ltm->tm_min,ltm->tm_sec);
        sleep(lam1*exp(-1*lam1*i));
    }
}
// Main Function
int main(){
    srand(time(0));
    // Input Parameters
    int N,K,lam1;
    FILE *inp = fopen("inpparams.txt","r");
    fscanf(inp,"%d %d %d",&N,&K,&lam1);
    fclose(inp);

    // Required Variables
    cout<<fixed<<setprecision(1);
    cout<<"N value is: "<<N<<"\n";
    cout<<"K value is: "<<K<<"\n";
    time_taken = 0;
    thread test_thr[N];
    int data[N];

    // Lazy Syncronisation Testing
    FILE *out = fopen("lazy_output.txt","w");
    fprintf(out,"Lazy Synchronization Output:\n");
    Lazy *lazy_syn = new Lazy();
    for(int i = 0; i < N; i++){
        data[i] = i;
        test_thr[i] = thread(&test,out,N,K,data[i],lazy_syn,lam1);
    }
    for(int i = 0; i < N; i++)
        test_thr[i].join();
    printf("The Average Time taken to finish an operation for Lazy Synchronisation: %lld ns\n",time_taken/(N*K));
    fclose(out);
}