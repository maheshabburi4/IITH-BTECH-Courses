Compiling:
1. To compile the programs, use the following commands
        $ g++ ProgAssn5-OPTIMISTIC-CS18BTECH11001.cpp -o opt -pthread
        $ g++ ProgAssn5-LAZY-CS18BTECH11001.cpp -o lazy -pthread

Running:
1. To execute the programs, use the following commands
        $ ./opt
        $ ./lazy

Input:
1. The input is given in the file inpparams.txt
    N   : Number of Threads
    K   : Number of operations by each Thread
    lam : Average Sleep time of each Thread

Output:
1. The file optimistic_output.txt contains output when the optimistic algorithm is executed
2. The file lazy_output.txt contains output when the lazy algorithm is executed

Terminal Output:
1. The average time per each operation for given N, K is printed onto the Terminal.