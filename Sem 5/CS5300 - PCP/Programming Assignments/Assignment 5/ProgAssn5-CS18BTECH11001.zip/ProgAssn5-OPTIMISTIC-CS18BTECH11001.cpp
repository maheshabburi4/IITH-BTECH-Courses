#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;

atomic_llong time_taken;

// Structure for Node
class Node {
    public:
        int key;            // Data value storage
        Node* next;         // Linked List pointer
    
    private:
        mutex mtx;          // Mutex Lock to ensure one one thread access node at a time

    public:
        // Contructor initialisation of Node
        Node(int item){     
            key = item;
            next = NULL;
        }

        // Lock method of Node to apply locking to Node Position
        void lock(){        
            mtx.lock();
        }
        
        // Unlock method of Node to apply Unlocking to Node position
        void unlock(){      
            mtx.unlock();
        }
};

class Optimistic{
    // Data Variables of the set
    Node* head = NULL;
    Node* tail = NULL;

    // Member functions
    public:
        // Constructor for initialising Data Variables of Set
        Optimistic(){                   
            head = new Node(INT_MIN);
            tail = new Node(INT_MAX);
            head->next = tail;
        }

        // The add(item) Method adds x to the set, 
        // returning true if, and only if x was not already there.
        bool add(int item) {
            int key = item;
            while(true) {
                Node* pred = head;
                Node* curr = pred->next;
                while(curr->key < key) {
                    pred = curr;
                    curr = curr->next;
                }
                pred->lock();
                curr->lock();
                if(validate(pred,curr)) {
                    if(curr->key == key) {
                        pred->unlock();
                        curr->unlock();
                        return false;
                    } else {
                        Node* node = new Node(item);
                        node->next = curr;
                        pred->next = node;
                        pred->unlock();
                        curr->unlock();
                        return true;
                    }
                }
                pred->unlock();
                curr->unlock();
            }
        }

        // The remove(x) method removes x from the set, 
        // returning true if, and only if x was there.
        bool remove(int item) {
            int key = item;
            while(true) {
                Node* pred = head;
                Node* curr = pred->next;
                while(curr->key < key) {
                    pred = curr;
                    curr = curr->next;
                }
                pred->lock();
                curr->lock();
                if(validate(pred,curr)) {
                    if(curr->key == key) {
                        pred->next = curr->next;
                        pred->unlock();
                        curr->unlock();
                        return true;
                    } else {
                        pred->unlock();
                        curr->unlock();
                        return false;
                    }
                }
                pred->unlock();
                curr->unlock();
            }
        }

        // The contains(x) returns true if, and only if the set contains x.
        bool contains(int item) {
            int key = item;
            while(true) {
                Node* pred = head;
                Node* curr = pred->next;
                while(curr->key < key) {
                    pred = curr;
                    curr = curr->next;
                }
                pred->lock();
                curr->lock();
                if(validate(pred,curr)) {
                    pred->unlock();
                    curr->unlock();
                    return curr->key == key;
                } 
                pred->unlock();
                curr->unlock();
            }
        }

    private:
        // Private function to be used by above public functions
        bool validate(Node* pred, Node* curr) {
            Node* node = head;
            while(node->key <= pred->key) {
                if(node == pred)
                    return pred->next == curr;
                node = node->next;
            }
            return false;
        }
};

void test(FILE* out, int N, int K, int thread_id, Optimistic* opt_syn, int lam1) {
    int id = thread_id;             // Fetching Thread id
    for(int i = 1; i <= K; i++) {
        int op = rand()%3;          // Choosing option randomly
        int number = rand()%(K*N);  // choose a number randomly to per form the operation
        int result;
        string oper, res;
        time_point<system_clock> start = system_clock::now();
        switch (op) {
        case 0:
            result = opt_syn->add(number);
            oper = "add";
            break;
        
        case 1:
            result = opt_syn->remove(number);
            oper = "remove";
            break;
        
        case 2:
            result = opt_syn->contains(number);
            oper = "contains";
            break;
        
        default:
            break;
        }  
        time_point<system_clock> end = system_clock::now();
        time_t endTime = system_clock::to_time_t(end);
        tm *ltm = localtime(&endTime);
        time_taken += duration_cast<nanoseconds>(end - start).count();
        if(result) 
            res = "True"; 
        else 
            res = "False"; 
        fprintf(out, "Thread %d performs %s with number %d in round %d with results %s at %d:%d:%d\n",thread_id,oper.c_str(),number,i,res.c_str(),ltm->tm_hour,ltm->tm_min,ltm->tm_sec);
        sleep(lam1*exp(-1*lam1*i));
    }
}
// Main Function
int main(){
    srand(time(0));
    // Input Parameters
    int N,K,lam1;
    FILE *inp = fopen("inpparams.txt","r");
    fscanf(inp,"%d %d %d",&N,&K,&lam1);
    fclose(inp);

    // Required Variables
    cout<<fixed<<setprecision(1);
    cout<<"N value is: "<<N<<"\n";
    cout<<"K value is: "<<K<<"\n";
    time_taken = 0;
    thread test_thr[N];
    int data[N];

    // Optimistic Syncronisation Testing
    FILE *out = fopen("optimistic_output.txt","w");
    fprintf(out,"Optimistic Synchronization Output:\n");
    Optimistic *opt_syn = new Optimistic();
    for(int i = 0; i < N; i++){
        data[i] = i;
        test_thr[i] = thread(&test,out,N,K,data[i],opt_syn,lam1);
    }
    for(int i = 0; i < N; i++)
        test_thr[i].join();
    printf("The Average Time taken to finish an operation for Optimistic Synchronisation: %lld ns\n",time_taken/(N*K));
    fclose(out);
}