#include<bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;
//  The stamped snapshot class 
class StampedSnap{
    public:
        // Data Variables
        int value;
        int pid;
        int snap;

        // Dummy Constructor required
        StampedSnap() noexcept {}

        // Initialisation Functions
        StampedSnap(int value){
            this->value = value;
            this->pid = 0;
            this->snap = 0;
        }
        StampedSnap(int value, int pid, int snap) {
            this->value = value;
            this->pid = pid;
            this->snap = snap;
        }
};
// The single writer atomic snapshot class
class MRMW_Snap{
    private:
        atomic<int>* sn;
        atomic<StampedSnap> *REG;
        atomic<int*>* HELPSNAP;
        int capacity;
        int N;

    public: 
        MRMW_Snap(int N, int capacity, int init) {
            this->N = N;
            this->capacity = capacity;
            sn = new atomic<int>[N];
            REG = new atomic<StampedSnap>[capacity];
            HELPSNAP = new atomic<int*>[N];
            for (int i = 0; i < capacity; i++) {
                StampedSnap use_snap(init);
                REG[i].store(use_snap);
            }
            for (int i = 0; i < N; i++) {
                HELPSNAP[i] = new int[capacity];
            }
        }
        void update(int thread_id, int loc, int value) {
            sn[thread_id]++;
            StampedSnap use_snap(value,thread_id,sn[thread_id].load());
            REG[loc].store(use_snap);
            HELPSNAP[thread_id] = scan();
        }
        atomic<StampedSnap>* collect() {
            atomic<StampedSnap>* copy = new atomic<StampedSnap>[capacity];
            for (int j = 0; j < capacity; j++){
                StampedSnap copyValue = REG[j].load();
                StampedSnap use_snap(copyValue.value,copyValue.pid,copyValue.snap);
                copy[j].store(use_snap);
            }
            return copy;
        }
        int* scan() {
            atomic<StampedSnap>* oldCopy;
            atomic<StampedSnap>* newCopy;
            bool *moved = new bool[N];
            oldCopy = collect();
            while(true){
                newCopy = collect();
                for (int j = 0; j < capacity; j++) {
                    if (oldCopy[j].load().pid != newCopy[j].load().pid || oldCopy[j].load().value != newCopy[j].load().value || oldCopy[j].load().snap != newCopy[j].load().snap) {
                        if (moved[newCopy[j].load().pid]) {
                            return HELPSNAP[newCopy[j].load().pid];
                        } else {
                            moved[newCopy[j].load().pid] = true;
                            oldCopy = newCopy;
                        }
                    }
                }
                int *result = new int[capacity];
                for (int j = 0; j < capacity; j++)
                    result[j] = newCopy[j].load().value;
                return result;
            }
        }
};

// Global variables
int N,M,muw,mus,K,MAX=100000000;
MRMW_Snap *MRMW_SnapObj;
bool term;
vector<vector<pair<long long int,string>>> logData;
vector<int> timeCollects;

// function for writer threads
void writer(int tid){
    int l,v,pid,t1;
    pid = tid;
    exponential_distribution<double> distribution(muw);
    default_random_engine generator;
    while(!term){                               // execute until term flag is set true
        v = rand()%100;                         // Get a random integer
        l = rand()%M;                           // Get a random location in the range 0..M-1

        // Update function call
        MRMW_SnapObj->update(pid, l, v);

        // record system time and value in local log
        auto start = system_clock::now();
        long long int dur = (duration_cast<nanoseconds>(start.time_since_epoch()).count())%MAX;
        string buff = "Thr" + to_string(pid+1)+ "'s write of "+ to_string(v)+ " on location " + to_string(l+1) + " at " + to_string(dur);
        logData[pid].push_back(make_pair(dur,buff));

        // sleep time exponentially distributed with an avg of muw;
        t1 = distribution(generator);
        sleep(t1);
    }
}

// function for snapsht thread
void snapshot(){
    int i=0;
    int t2;
    exponential_distribution<double> distribution(mus);
    default_random_engine generator;
    while(i < K){
        auto beginCollect = system_clock::now();                // system time before ith snapshot
        int *result = MRMW_SnapObj->scan();                     // collect the snapshot
        auto endCollect = system_clock::now();                  // system time after ith snapshot
        auto timeCollect = duration_cast<nanoseconds>(endCollect - beginCollect).count();

        // store ith snapshot and timeCollect
        long long int dur = (duration_cast<nanoseconds>(endCollect.time_since_epoch()).count())%MAX;
        string buff = "Snapshot Thr’s snapshot: ";
        for(int j=0;j<M;j++)
            buff += "l"+to_string(j+1)+":"+to_string(result[j])+" ";
        buff += "which finished at " + to_string(dur);
        logData[N-1].push_back(make_pair(dur,buff));
        
        // store timeCollect 
        timeCollects[i] = timeCollect;

        // sleep time exponentially distributed with an avg of muw;
        t2 = distribution(generator);
        sleep(t2);

        i++;
    }
}

int main(){
    // Input Parameters
    FILE *inp = fopen("inp-params.txt","r");
    fscanf(inp,"%d %d %d %d %d",&N,&M,&muw,&mus,&K);
    fclose(inp);
    
    // Initialisation of Shared Variables
    logData.resize(N+1);
    timeCollects.resize(K);
    MRMW_SnapObj = new MRMW_Snap(N,M,0);
    term = false;

    // Required Variables
    FILE *out = fopen("mrmw-output.txt","w");
    thread write[N];
    int data[N];
    thread snapshot_collector;

    // Writer Threads
    fprintf(out,"MRMW snapshot output:\n");
    for(int i=0;i<N;i++){
        data[i] = i;
        write[i] = thread(&writer,data[i]);
    }

    // Collecting Snapshot
    snapshot_collector = thread(&snapshot);

    // wait until snapshot thread terminates
    snapshot_collector.join();

    // Inform all the writer threads that they have to terminate
    term = true;

    // wait until all the writer threads terminate
    for(int i=0;i<N;i++)
        write[i].join();

    // collecting log values
    vector<pair<long long int, string>> finlog;
    for(int i = 0; i < logData.size(); i++){
        for(int j = 0; j < logData[i].size(); j++){
            finlog.push_back(logData[i][j]);
        }
    }

    // sorting according to the collected time
    sort(finlog.begin(),finlog.end());

    // Printing onto the file
    for(int i = 0; i < finlog.size();i++){
        fprintf(out,"%s\n",finlog[i].second.c_str());
    }

    // close the output file
    fclose(out);

    // Printing worst and average time taken for collecting snapshots
    int avtime=0, wrtime;
    for(int i = 0 ; i < timeCollects.size(); i++)
        avtime += timeCollects[i];
    avtime /= K;
    wrtime = *max_element(timeCollects.begin(),timeCollects.end());
    printf("N value is: %d\n",N);
    printf("M value is: %d\n",M);
    printf("Ratio of average delays value is: %.1lf\n",(double)mus/muw);
    printf("Average time for MRMW snapshot collection: %d ns\n",avtime);
    printf("Worstcase time for MRMW snapshot collection: %d ns\n",wrtime);
}