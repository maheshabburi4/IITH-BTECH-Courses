#include<bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;
//  The stamped snapshot class 
class StampedSnap{
    public:
        // Data Variables
        long stamp;
        int value;
        int* snap;

        // Dummy Constructor required
        StampedSnap() noexcept {}

        // Initialisation Constructors
        StampedSnap(int val) {
            stamp = 0;
            value = val;
            snap = NULL;
        }
        StampedSnap(long label, int val, int* snp) {
            stamp = label;
            value = val;
            snap = snp;
        }
};
// The single writer atomic snapshot class
class MRSW_Snap{
    private:
        atomic<StampedSnap> *a_table;           // array of MRSW registers
        int capacity;                           // number of MRSW registers

        atomic<StampedSnap>* collect() {
            atomic<StampedSnap>* copy = new atomic<StampedSnap>[capacity];
            for (int j = 0; j < capacity; j++){
                StampedSnap copyValue = a_table[j].load();
                StampedSnap use_snap(copyValue.stamp,copyValue.value,copyValue.snap);
                copy[j].store(use_snap);
            }
            return copy;
        }

    public: 
        MRSW_Snap(int capacity, int init) {
            this->capacity = capacity;
            a_table = new atomic<StampedSnap>[capacity];
            for (int i = 0; i < capacity; i++) {
                StampedSnap use_snap(init);
                a_table[i].store(use_snap);
            }
        }
        void update(int thread_id, int value) {
            int me = thread_id;
            int* snap = scan();
            StampedSnap oldValue = a_table[me].load();
            StampedSnap newValue = StampedSnap(oldValue.stamp+1, value, snap);
            a_table[me].store(newValue);
        }
        int* scan() {
            atomic<StampedSnap>* oldCopy;
            atomic<StampedSnap>* newCopy;
            bool *moved = new bool[capacity];
            oldCopy = collect(); 
            while (true) {
                bool flag = false;
                newCopy = collect();
                for (int j = 0; j < capacity; j++) {
                    if (oldCopy[j].load().stamp != newCopy[j].load().stamp) {
                        if (moved[j]) {
                            return newCopy[j].load().snap;
                        } else {
                            moved[j] = true;
                            oldCopy = newCopy;
                            flag = true;
                            break;
                        }
                    }
                }
                if(flag)
                    continue;
                int *result = new int[capacity];
                for (int j = 0; j < capacity; j++)
                    result[j] = newCopy[j].load().value;
                return result;
            }
        }
};

// Global variables
int N,M,muw,mus,K,MAX=100000000;
MRSW_Snap *MRSW_SnapObj;
bool term;
vector<vector<pair<long long int,string>>> logData;
vector<int> timeCollects;

// function for writer threads
void writer(int tid){
    int l,v,pid,t1;
    pid = tid;
    exponential_distribution<double> distribution(muw);
    default_random_engine generator;
    while(!term){                   // execute until term flag is set true
        v = rand()%100;             // Get a random integer
        l = pid;                    // set location same as thread_id

        // Update function call
        MRSW_SnapObj->update(l,v);

        // record system time and value in local log
        auto start = system_clock::now();
        long long int dur = (duration_cast<nanoseconds>(start.time_since_epoch()).count())%MAX;
        string buff = "Thr" + to_string(pid+1)+ "'s write of "+ to_string(v)+ " at " + to_string(dur);
        logData[pid].push_back(make_pair(dur,buff));

        // sleep time exponentially distributed with an avg of muw;
        t1 = distribution(generator);
        sleep(t1);
    }
}

// function for snapsht thread
void snapshot(){
    int i=0;
    int t2;
    exponential_distribution<double> distribution(mus);
    default_random_engine generator;
    while(i < K){
        auto beginCollect = system_clock::now();            // system time before ith snapshot
        int *result = MRSW_SnapObj->scan();                 // collect the snapshot
        auto endCollect = system_clock::now();              // system time after ith snapshot
        auto timeCollect = duration_cast<nanoseconds>(endCollect - beginCollect).count();

        // store ith snapshot
        long long int dur = (duration_cast<nanoseconds>(endCollect.time_since_epoch()).count())%MAX;
        string buff = "Snapshot Thr’s snapshot: ";
        for(int j=0;j<M;j++)
            buff += "l"+to_string(j+1)+":"+to_string(result[j])+" ";
        buff += "which finished at " + to_string(dur);
        logData[N-1].push_back(make_pair(dur,buff));
        
        // store timeCollect 
        timeCollects[i] = timeCollect;

        // sleep time exponentially distributed with an avg of muw;
        t2 = distribution(generator);
        sleep(t2);
    
        i++;
    }
}

int main(){
    // Input Parameters
    FILE *inp = fopen("inp-params.txt","r");
    fscanf(inp,"%d %d %d %d %d",&N,&M,&muw,&mus,&K);
    fclose(inp);
    
    // Initialisation of Shared Variables
    logData.resize(N+1);
    timeCollects.resize(K);
    MRSW_SnapObj = new MRSW_Snap(N,0);
    term = false;

    // Required Variables
    FILE *out = fopen("mrsw-output.txt","w");
    thread write[N];
    int data[N];
    thread snapshot_collector;

    // Writer Threads
    fprintf(out,"MRSW snapshot output:\n");
    for(int i=0;i<N;i++){
        data[i] = i;
        write[i] = thread(&writer,data[i]);
    }

    // Collecting Snapshot
    snapshot_collector = thread(&snapshot);

    // wait until snapshot thread terminates
    snapshot_collector.join();

    // Inform all the writer threads that they have to terminate
    term = true;

    // wait until all the writer threads terminate
    for(int i=0;i<N;i++)
        write[i].join();

    // collecting log values
    vector<pair<long long int, string>> finlog;
    for(int i = 0; i < logData.size(); i++){
        for(int j = 0; j < logData[i].size(); j++){
            finlog.push_back(logData[i][j]);
        }
    }

    // sorting according to the collected time
    sort(finlog.begin(),finlog.end());

    // Printing onto the file
    for(int i = 0; i < finlog.size();i++){
        fprintf(out,"%s\n",finlog[i].second.c_str());
    }

    // close the output file
    fclose(out);

    // Printing worst and average time taken for collecting snapshots
    int avtime=0, wrtime;
    for(int i = 0 ; i < timeCollects.size(); i++)
        avtime += timeCollects[i];
    avtime /= K;
    wrtime = *max_element(timeCollects.begin(),timeCollects.end());
    printf("N value is: %d\n",N);
    printf("M value is: %d\n",M);
    printf("Ratio of average delays value is: %.1lf\n",(double)mus/muw);
    printf("Average time for MRSW snapshot collection: %d ns\n",avtime);
    printf("Worstcase time for MRSW snapshot collection: %d ns\n",wrtime);
}