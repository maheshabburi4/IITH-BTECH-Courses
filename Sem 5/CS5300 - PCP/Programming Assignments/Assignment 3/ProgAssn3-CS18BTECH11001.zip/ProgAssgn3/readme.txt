Precompilation Steps:
1. Download the ProgAssn3-CS18BTECH11001.zip
2. Extract the Downloaded zip file
3. Enter the Extracted folder

Compiling:
1. Open the terminal in the present directory
2. To compile mrsw-CS18BTECH11001.cpp execute the following command
    $ g++ -o mrsw mrsw-CS18BTECH11001.cpp -latomic -pthread
3. To compile mrmw-CS18BTECH11001.cpp execute the following command
    $ g++ -o mrmw mrmw-CS18BTECH11001.cpp -latomic -pthread

Running:
1. First ensure whether the inp-params.txt is present
2. To run the mrsw algorithm execute the following command
    $ ./mrsw
3. To run the mrmw algorithm execute the following command
    $ ./mrmw

Input:
1. The input is given in the inp-params.txt
2. The input is a five spaced integers represeting
    N   -> Number of writer threads
    M   -> Size of snapshot object
    muw -> Average delay of writer thread distributed exponentially
    mus -> Average delay of snapshot thread distributed exponentially

Terminal Output:
1. The Output printed in the terminal represents the input parameters, 
   Average time and worst case time for each snapshot. 

File Output:
1. The file mrsw-output.txt contains the order in which the mrsw operations have been completed.
2. The file mrmw-output.txt contains the order in which the mrmw operations have been completed.
3. I printed the time stamp as the last 8digits of number of nanoseconds elapsed till now from the time of epoch.