#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;

// Variables for calculating average times
atomic_llong csEnterTime, csExitTime;

// Base class to be inherited and used for overriding
// Pure Virtual Functions are used
class Lock{
    public:
        virtual void lock(int id) = 0;
        virtual void unlock(int id) = 0;
};

// QNode class used in MCS implementation     
class QNode{
    public:
        // Linked List
        bool locked = false;
        QNode *next = NULL;
};

// MCSLock class implementing MCS Lock
class MCSLock : public Lock{
    atomic<QNode*> *tail;
    QNode **myNode;

    public:
    // Constructor
    MCSLock(int N){
        tail = new atomic<QNode*>(NULL);
        myNode = new QNode*[N];
        for(int i = 0; i < N; i++){
            myNode[i] = new QNode();
        }
    }
    // Lock function
    void lock(int id){
        QNode *qnode = myNode[id];
        QNode *pred = tail->exchange(qnode);
        if(pred != NULL){
            qnode->locked = true;
            pred->next = qnode;
            while(qnode->locked);
        }
    }
    // Unlock function
    void unlock(int id){
        QNode *qnode = myNode[id];
        if(qnode->next == NULL){
            if(tail->compare_exchange_strong(qnode, NULL))
                return;
            while(qnode->next == NULL);
        }
        qnode->next->locked = false;
        qnode->next = NULL;
    }
};

// Function fot testing Lock
void testCS(int thread_id, Lock *Test, FILE *out, int K, int lam1, int lam2){
    int id = thread_id;
    for(int i = 1; i <= K; i++){
        time_point<system_clock> start, end;
        
        // Request Enter Time
        start = system_clock::now();
        time_t reqEnterTime = system_clock::to_time_t(start);
        tm* ltm1 = localtime(&reqEnterTime);
        // fprintf(out,"%dth CS Entry Request at %d:%d:%d by thread %d (mesg 1)\n",i,ltm1->tm_hour,ltm1->tm_min,ltm1->tm_sec,id);
        
        Test->lock(id);                             // Locking before Entering CS
        
        // Actual Enter Time
        end = system_clock::now();
        time_t actEnterTime = system_clock::to_time_t(end);
        csEnterTime += duration_cast<microseconds>(end - start).count();
        tm* ltm2 = localtime(&actEnterTime);
        fprintf(out,"%dth CS Entry at %d:%d:%d by thread %d (mesg 2)\n",i,ltm2->tm_hour,ltm2->tm_min,ltm2->tm_sec,id);
        
        sleep(lam1*exp(-1*lam1*i));                 // time1 sleep time
        
        // Request Exit Time
        start = system_clock::now();
        time_t reqExitTime = system_clock::to_time_t(start);
        tm *ltm3 = localtime(&reqExitTime);
        fprintf(out,"%dth CS Exit Request at %d:%d:%d by thread %d (mesg 3)\n",i,ltm3->tm_hour,ltm3->tm_min,ltm3->tm_sec,id);
        
        Test->unlock(id);                           // Unlocking after Exiting CS
        
        // Actual Exit Time
        end = system_clock::now();
        time_t actExitTime = system_clock::to_time_t(end);
        csExitTime += duration_cast<microseconds>(end - start).count();
        tm *ltm4 = localtime(&actExitTime);
        // fprintf(out,"%dth CS Exit at %d:%d:%d by thread %d (mesg 4)\n",i,ltm4->tm_hour,ltm4->tm_min,ltm4->tm_sec,id);
        
        sleep(lam2*exp(-1*lam2*i));                 // time2 sleep time
    }
}

// Main Function
int main(){
    // Input Parameters
    int N,K,lam1,lam2;
    FILE *inp = fopen("inp-params.txt","r");
    fscanf(inp,"%d %d %d %d",&N,&K,&lam1,&lam2);
    fclose(inp);

    // Required Variables
    cout<<fixed<<setprecision(1);
    cout<<"N value is: "<<N<<"\n";
    cout<<"K value is: "<<K<<"\n";
    FILE *out = fopen("mcs_output.txt","w");
    thread test[N];
    int data[N];

    // MCS Lock Testing
    fprintf(out,"MCS Lock Output:\n");
    MCSLock *mcs_lock = new MCSLock(N);
    csEnterTime = csExitTime = 0;
    for(int i = 0; i < N; i++){
        data[i] = i;
        test[i] = thread(&testCS,data[i],mcs_lock,out,K,lam1,lam2);
    }
    for(int i = 0; i < N; i++)
        test[i].join();
    cout<<"Average CS Enter time for MCS Lock is: "<<(double)csEnterTime/(N*K)<<"\n";
    cout<<"Average CS Exit time for MCS Lock is: "<<(double)csExitTime/(N*K)<<"\n";
    fclose(out);
}