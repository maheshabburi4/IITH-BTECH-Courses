Precompilation Steps:
1. Download the ProgAssn4-CS18BTECH11001.zip
2. Extract the Downloaded zip file
3. Enter the Extracted folder

Compiling:
1. Open the terminal in the present directory
2. To compile CLH-CS18BTECH11001.cpp execute the following command
    $ g++ -o CLH CLH-CS18BTECH11001.cpp -latomic -pthread
3. To compile MCS-CS18BTECH11001.cpp execute the following command
    $ g++ -o MCS MCS-CS18BTECH11001.cpp -latomic -pthread

Running:
1. First ensure whether the inp-params.txt is present
2. To run the CLH algorithm execute the following command
    $ ./CLH
3. To run the MCS algorithm execute the following command
    $ ./MCS

Input:
1. The input is given in the inp-params.txt
2. The input is a four spaced integers represeting
    N    -> Number of threads
    K    -> Number of critical section requests by each thread
    lam1 -> Average delay for enter time of each thread distributed exponentially
    lam2 -> Average delay for exit time of each thread distributed exponentially

Terminal Output:
1. The Output printed in the terminal represents the input parameters, 
   Average of Enter and Exit time over all threads. 

File Output:
1. The file CLH-output.txt contains the order in which the CLH operations have been completed.
2. The file MCS-output.txt contains the order in which the MCS operations have been completed.
3. I printed the time stamp for each Enter and Exit time.
4. To Print the Requests Times in the ouput file remove the comment for the printing part in testCS function.