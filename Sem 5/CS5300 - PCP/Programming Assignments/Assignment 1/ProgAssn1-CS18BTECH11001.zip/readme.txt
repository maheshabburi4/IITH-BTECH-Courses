Compile:
Download the zip file from the classroom and extract it.
Enter into the extracted folder.
Open the terminal in the present directory.
Enter the following command. 
    $ g++ Src-CS18BTECH11001.cpp -pthread
As I have used the pthreads in the source program it is mandatory to compile with pthread option as shown.

Running:
In the above terminal enter the following command.
    $ ./a.out
Make sure you have kept the input file "inp-params.txt" before running the program.

Input:
In the "inp-params.txt" enter two integers n and m seperated by a space, representing the (N=10^n) and the no. of threads respectively.

Output:
The following output files will be created.
1. Primes-DAM.txt   -   Primes printed while running the DAM algorithm.
2. Primes-SAM1.txt  -   Primes printed while running the SAM1 algorithm.
3. Primes-SAM2.txt  -   Primes printed while running the SAM2 algorithm.
4. Times.txt        -   3 values denoting the times taken by the DAM, SAM1, SAM2 algorithm in seconds respectively.