#include<bits/stdc++.h>
#include<sys/time.h>
using namespace std;
#define int long long

    // Filestream Variables
ifstream inFile;
ofstream outFile,times;

    // mutex lock for Synchronized printing
mutex mtx;

// function for checking and printing a prime number
// Logic:
// Every number can be represented as 
// 6n, 6n+1, 6n+2, 6n+3, 6n+4, 6n+5, 6n+6
// as other than 6n+1 and 6n+5 all are either divisible by 2 or 3.
// So first if the number is divisible by 2 or 3 
// and then check 6n+1 and 6n+5
void isPrime(int a){
    if(a<=1)
        return ;
    if(a<=3){
            // lock before printing
        mtx.lock();
        outFile<<a<<" ";
            // unlock after printing 
        mtx.unlock();
        return ;
    }

    // check for divisibility with 2 or 3
    if(a%2==0 || a%3==0)
        return ;

    // check for divisibility with 6n+1, 6n+5
    for(int i=5;i*i<=a;i+=6)
        if(a%i==0 || a%(i+2)==0)
            return;
        // lock before printing
    mtx.lock();
    outFile<<a<<" ";
        // unloack after printing
    mtx.unlock();
    return ;
}


    // class required for DAM 
class Counter{
    private:
            // atomic variable to avoid synchonisation issues
        atomic_llong value;
    public:
            // Constructor for initialising the variable
        Counter(int i){
            value = i;
        }
            // Increment function
        int getAndIncrement(){
            return value+=1;
        }
};
    // Global counter variable 
Counter counter(1);
    
    // DAM implementation 
void* dam(void* arg){
        // fetching data from argument
    int N = (int)arg;
    int i = counter.getAndIncrement();
    while(i<N){
        isPrime(i);
        i = counter.getAndIncrement();
    }
}


// Structure required for SAM1 & SAM2
struct thread_data{
    int start;      // for the starting number
    int step;       // increment step
    int limit;      // maximum limit to check
};
    
    // SAM1 implementation
void* sam1(void* arg){
        // fetching data from argument
    thread_data *temp = (thread_data*)arg;
    int i = temp->start,step = temp->step, limit = temp->limit;
    while(i<limit){
        isPrime(i);
        i += step;
    }
}

    // SAM2 implementation
void* sam2(void* arg){
        // fetching data from argument
    thread_data *temp = (thread_data*)arg;
    int i = temp->start,step = temp->step, limit = temp->limit;
    while(i<limit){
        isPrime(i);
        i += step;
    }
}



// main function
int32_t main(){
        // input from file
    int N,M;
    inFile.open("inp-params.txt",ios::in);
    inFile>>N>>M;
    inFile.close();

    printf("n value is : %lld\nm value is : %lld\n",N,M);
        
        // Times file set up
    times.open("Times.txt",ios::out);
    times<<fixed<<setprecision(6);
    
    N = pow(10,N);
    pthread_t players[M];
    struct timeval time0,time1;

        // DAM implementation
    outFile.open("Primes-DAM.txt",ios::out);
    outFile.clear();            // clearing the file using main thread
    for(int i=0;i<M;i++)
        pthread_create(&players[i],NULL,dam,(void *)N);
    gettimeofday(&time0,NULL);
    for(int i=0;i<M;i++)
        pthread_join(players[i],NULL);
    gettimeofday(&time1,NULL);
    outFile.close();
    times<<(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001<<" ";
    printf("Time for DAM is  : %lf\n",(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001);
    
        // SAM1 implementation
    outFile.open("Primes-SAM1.txt",ios::out);
    outFile.clear();        // clearing the file using main thread
    thread_data *data; 
    for(int i=0;i<M;i++){
            // initialising structure with required values to pass into function
        data = new thread_data;
        data->start = i;
        data->step = M;
        data->limit = N;
        pthread_create(&players[i],NULL,sam1,(void *)data);
    }
    gettimeofday(&time0,NULL);
    for(int i=0;i<M;i++)
        pthread_join(players[i],NULL);
    gettimeofday(&time1,NULL);
    outFile.close();
    times<<(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001<<" ";
    printf("Time for SAM1 is : %lf\n",(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001);
    
        // SAM2 implementation 
    outFile.open("Primes-SAM2.txt",ios::out);
    outFile.clear();            // clearing the file using main thread
    outFile<<"2 ";              // Printing 2 by main thread
    for(int i=0;i<M;i++){
            // initialising structure with required values to pass into function
        data = new thread_data;
        data->start = 2*i + 1;
        data->step = 2*M;
        data->limit = N;
        pthread_create(&players[i],NULL,sam2,(void *)data);
    }
    gettimeofday(&time0,NULL);
    for(int i=0;i<M;i++)
        pthread_join(players[i],NULL);
    gettimeofday(&time1,NULL);
    outFile.close();
    times<<(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001<<" ";
    printf("Time for SAM2 is : %lf\n",(double)(time1.tv_sec-time0.tv_sec) + (double)(time1.tv_usec-time0.tv_usec) * .000001);
    times.close();
}