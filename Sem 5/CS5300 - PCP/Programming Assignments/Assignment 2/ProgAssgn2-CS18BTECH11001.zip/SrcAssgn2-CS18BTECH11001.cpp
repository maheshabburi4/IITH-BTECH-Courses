#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;
using namespace std::chrono;

// Variables for calculating average times
atomic_llong csEnterTime, csExitTime;

// Base class to be inherited and used for overriding
// Pure Virtual Functions are used
class Lock{
    public:
        virtual void lock(int id) = 0;
        virtual void unlock(int id) = 0;
};

// Filter class implementing Filter Lock
class Filter: public Lock{
    private:
        int N;                          // No. of threads
        vector<int> level;              // Level Array
        vector<int> victim;             // Victim Array
    public:
    // Constructor
        Filter(int n){
            N = n;
            level.resize(N,0);
            victim.resize(N);
        }

    // lock method
    void lock(int me){
        for(int i = 1; i < N; i++){
            level[me] = i;
            victim[i] = me; 
            for(int k = 0; k < N; k++)
                while( k != me && level[k] >= i && victim[i] == me); 
        }
    }

    // unlock method
    void unlock(int me){
        level[me] = 0;
    }
};

// Peterson class Implementing PTL
class Peterson: public Lock{
    private:
        int N;                          // No. of threads
        vector<vector<int>> peter;      // Tree structure
    public:
    // Constructor
        Peterson(int n){
            N = n;
            peter.resize(N-1,vector<int>(3,0));
        }

    // lock method
    void lock(int me){
        for(int i = N + me; i > 1; i /= 2){
            peter[(i>>1) - 1][i%2] = 1;
            peter[(i>>1) - 1][2] = i%2;
            while(peter[(i>>1) - 1][1 - (i%2)] && peter[(i>>1) - 1][2] == (i%2));
        }
    }

    // unlock method
    void unlock(int me){
        for(int i = N + me; i > 1; i /= 2)
            peter[(i>>1) - 1][i%2] = 0;
    }
};

// Function fot testing Locks
void testCS(int thread_id, Lock *Test, FILE *out, int K, int lam1, int lam2){
    int id = thread_id;
    for(int i = 1; i <= K; i++){
        time_point<system_clock> start, end;
        
        // Request Enter Time
        start = system_clock::now();
        time_t reqEnterTime = system_clock::to_time_t(start);
        tm* ltm1 = localtime(&reqEnterTime);
        fprintf(out,"%dth CS Entry Request at %d:%d:%d by thread %d (mesg 1)\n",i,ltm1->tm_hour,ltm1->tm_min,ltm1->tm_sec,id);
        
        Test->lock(id);                             // Locking before Entering CS
        
        // Actual Enter Time
        end = system_clock::now();
        time_t actEnterTime = system_clock::to_time_t(end);
        csEnterTime += duration_cast<microseconds>(end - start).count();
        tm* ltm2 = localtime(&actEnterTime);
        fprintf(out,"%dth CS Entry at %d:%d:%d by thread %d (mesg 2)\n",i,ltm2->tm_hour,ltm2->tm_min,ltm2->tm_sec,id);
        
        sleep(lam1*exp(-1*lam1*i));                 // time1 sleep time
        
        // Request Exit Time
        start = system_clock::now();
        time_t reqExitTime = system_clock::to_time_t(start);
        tm *ltm3 = localtime(&reqExitTime);
        fprintf(out,"%dth CS Exit Request at %d:%d:%d by thread %d (mesg 3)\n",i,ltm3->tm_hour,ltm3->tm_min,ltm3->tm_sec,id);
        
        Test->unlock(id);                           // Unlocking after Exiting CS
        
        // Actual Exit Time
        end = system_clock::now();
        time_t actExitTime = system_clock::to_time_t(end);
        csExitTime += duration_cast<microseconds>(end - start).count();
        tm *ltm4 = localtime(&actExitTime);
        fprintf(out,"%dth CS Exit at %d:%d:%d by thread %d (mesg 4)\n",i,ltm4->tm_hour,ltm4->tm_min,ltm4->tm_sec,id);
        
        sleep(lam2*exp(-1*lam2*i));                 // time2 sleep time
    }
}
int main(){
    // Input Parameters
    int N,K,lam1,lam2;
    FILE *inp = fopen("inp-params.txt","r");
    fscanf(inp,"%d %d %d %d",&N,&K,&lam1,&lam2);
    fclose(inp);

    // Required Variables
    cout<<fixed<<setprecision(1);
    cout<<"N value is: "<<N<<"\n";
    cout<<"K value is: "<<K<<"\n";
    FILE *out = fopen("output.txt","w");
    thread test[N];
    int data[N];

    // Filter Lock Testing
    fprintf(out,"Filter Lock Output:\n");
    Filter *fil_lock = new Filter(N);
    csEnterTime = csExitTime = 0;
    for(int i = 0; i < N; i++){
        data[i] = i;
        test[i] = thread(&testCS,data[i],fil_lock,out,K,lam1,lam2);
    }
    for(int i = 0; i < N; i++)
        test[i].join();
    cout<<"Average CS Enter time for Filter Lock is: "<<(double)csEnterTime/(N*K)<<"\n";
    cout<<"Average CS Exit time for Filter Lock is: "<<(double)csExitTime/(N*K)<<"\n";

    // Peterson Tree Lock Testing
    fprintf(out,"\n\nPTL Output:\n");
    Peterson *ptl_lock = new Peterson(N);
    csEnterTime = csExitTime = 0;
    for(int i = 0; i < N; i++){
        data[i] = i;
        test[i] = thread(testCS,data[i],ptl_lock,out,K,lam1,lam2);
    }
    for(int i = 0; i < N; i++)
        test[i].join();
    cout<<"Average CS Enter time for PTL is: "<<(double)csEnterTime/(N*K)<<"\n";
    cout<<"Average CS Exit time for PTL is: "<<(double)csExitTime/(N*K)<<"\n";
    fclose(out);
}