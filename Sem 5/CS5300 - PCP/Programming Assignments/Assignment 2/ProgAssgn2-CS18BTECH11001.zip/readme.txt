Compile:
Download the zip file from the classroom and extract it.
Enter into the extracted folder.
Open the terminal in the present directory.
Enter the following command. 
    $ g++ SrcAssign2-CS18BTECH11001.cpp -pthread
As I have used the threads in the source program it is mandatory to compile with pthread option as shown.

Running:
In the above terminal enter the following command.
    $ ./a.out
Make sure you have kept the input file "inp-params.txt" before running the program.

Input:
In the "inp-params.txt" enter four integers N, K, lamda1 and lamda2 seperated by a space, representing 
no. of threads, no. of CS entries per thread, average of exponential distribution for time1 and time2 respectively.

Output:
The file with name "output.txt" will be created containing the request and actual time for entry and exit into Critical section for both the algorithms.
A output is printed on to the terminal depecting the average time taken by each thread to enter and exit Critical section for both the algorithms. 