from tkinter import Label
from warnings import simplefilter
import numpy as np
import random
import matplotlib.pyplot as plt

# board size 
board_size = 3

# number of games required for training each opponent
train_num_games = 10000

# number of games after which test the trained agent
num_test_trained_agent = 200

# number of games performed for testing
num_test_games = 100

# final testing games
test_games = 1000

# Tic-Tac-Toe Game
class Tic_Tac_Toe(object):

    # constructor function
    def __init__(self, n):
        self.n = n
        self.board = np.zeros((n, n))
        self.is_end = False
    
    # initialises the environment to beginining
    def init(self):
        self.board = np.zeros((self.n, self.n))
        self.is_end = False
    
    # Act method
    def act(self, position, symbol):
        self.board[position] = symbol

    # returns empty board positions
    def actions(self):
        positions = []
        for i in range(self.n):
            for j in range(self.n):
                if self.board[i, j] == 0:
                    positions.append((i, j))
        return positions

    # check if there is a winner in the board
    def winner(self):
        # check if any of rows are all equal
        for i in range(self.n):
            row_sum = sum(self.board[i, :])
            if row_sum == self.n:
                self.is_end = True
                return 1
            if row_sum == -self.n:
                self.is_end = True
                return -1
        
        # check if any of columns are all equal
        for i in range(self.n):
            col_sum = sum(self.board[:, i])
            if col_sum == self.n:
                self.is_end = True
                return 1
            if col_sum == -self.n:
                self.is_end = True
                return -1
        
        # check if any of diagonal are all equal
        diag_sum1 = sum([self.board[i, i] for i in range(self.n)])
        diag_sum2 = sum([self.board[i, self.n - i -1] for i in range(self.n)])
        if diag_sum1 == self.n or diag_sum2 == self.n:
            self.is_end = True
            return 1
        if diag_sum1 == -self.n or diag_sum2 == -self.n:
            self.is_end = True
            return -1

        # if there are no positions left
        if len(self.actions()) == 0:
            self.is_end = True
            return 0
        
        # if there are empty spaces left to play
        self.is_end = False
        return None

    # return reward for the present state
    def reward(self):
        result = self.winner()
        if result == 1:
            return 10
        if result == -1:
            return -10
        if result == 0:
            return 1
        return 0

    # return state of board as a sring
    def state(self):
        return str(self.board.reshape(self.n*self.n))


# Random Agent
class Agent_Random(object):

    # constructor function
    def __init__(self):
        pass

    # policy for random agent
    def policy(self, environment):
        # find the available actions
        actions = environment.actions()

        # return a random action
        return random.choice(actions)

# Safe Agent
class Agent_Safe(object):

    # constructor function
    def __init__(self):
        pass
    
    # policy for safe agent
    def policy(self, environment):
        # find the available actions
        actions = environment.actions()

        # check if there is a possibility of win in any row
        for i in range(environment.n):
            row_sum = sum(environment.board[i, :])
            if row_sum == 1 - environment.n:
                return (i, list(environment.board[i, :]).index(0))

        # check if there is a possibility of win in any row
        for i in range(environment.n):
            col_sum = sum(environment.board[:, i])
            if col_sum == 1 - environment.n:
                return (list(environment.board[:, i]).index(0), i)

        # check if there is a possiblity of win in diagonal
        diag_1 = [environment.board[i, i] for i in range(environment.n)]
        diag_2 = [environment.board[i, environment.n - i -1] for i in range(environment.n)]
        
        if sum(diag_1) == 1 - environment.n:
            return (diag_1.index(0), diag_1.index(0))

        if sum(diag_2) == 1 - environment.n:
            return (diag_2.index(0), environment.n - 1 - diag_2.index(0))

        # check if there is a possibility of block in any row
        for i in range(environment.n):
            row_sum = sum(environment.board[i, :])
            if row_sum == environment.n - 1:
                return (i, list(environment.board[i, :]).index(0))

        # check if there is a possibility of block in any row
        for i in range(environment.n):
            col_sum = sum(environment.board[:, i])
            if col_sum == environment.n - 1:
                return (list(environment.board[:, i]).index(0), i)

        # check if there is a possiblity of block in diagonal
        diag_1 = [environment.board[i, i] for i in range(environment.n)]
        diag_2 = [environment.board[i, environment.n - i -1] for i in range(environment.n)]
        
        if sum(diag_1) == environment.n - 1:
            return (diag_1.index(0), diag_1.index(0))

        if sum(diag_2) == environment.n - 1:
            return (diag_2.index(0), environment.n - 1 - diag_2.index(0))

        # if there is no winning or blocking moves
        return random.choice(actions)

# Qlearn Agent
class Agent_Qlearn(object):

    # constructor function
    def __init__(self):
        self.alpha = 0.01
        self.gamma = 0.9
        self.epsilon = 0.05
        self.Q_table = {}
    
    # Choose the action to try in this state
    def choose(self, environment):
        # find actions that can be performed
        actions = environment.actions()

        # choose the type of exploration
        p = random.random()

        # random round
        if p < self.epsilon:
            return random.choice(actions)
        else:
            return self.policy(environment, actions)

    # policy for chosing best action
    def policy(self, environment, actions):
        # extract state from environment
        s = environment.state()

        # select the best action for the state
        max_value = max([self.Q(s, a) for a in actions])
        max_actions = [a for a in actions if self.Q(s,a) == max_value]
        return random.choice(max_actions)

    # extract Q value of (s, a) from Q table
    def Q(self, s, a):
        if (s, a) in self.Q_table:
            return self.Q_table[(s, a)]
        self.Q_table[(s, a)] = 0
        return self.Q_table[(s, a)]
        
    # observe the environment
    def observe(self, environment, state_before_agent, action_performed, state_after_agent):
        # find actions of the environment
        actions = environment.actions()

        # reward of present state
        reward = environment.reward()

        # update the Q table
        if len(actions) == 0:
            max_value = 0
        else:
            max_value = max([self.Q(state_after_agent, a) for a in actions])
        self.Q_table[(state_before_agent, action_performed)] = self.Q(state_before_agent, action_performed) + self.alpha*(reward + self.gamma*max_value - self.Q(state_before_agent, action_performed))

# function for playing opponent turn
def play_opponent_turn(environment, opponent):
    # choose the appropriate action using the opponent policy
    appropriate_action = opponent.policy(environment)

    # Perform the above choosen action
    environment.act(appropriate_action, -1)

    # return the action performed
    return environment, appropriate_action

# function for playing agent turn
def play_agent_turn(environment, agent):
    # choose the best move by the agent
    appropriate_action = agent.choose(environment)

    # Perform the above chosen action
    environment.act(appropriate_action, 1)

    # return the action performed
    return environment, appropriate_action

# Program to test the agent against opponents
def test(environment, agent, opponent, num_rounds = num_test_games, debug = False):
    rewards = []
    # test with the num_rounds
    for game_num in range(num_rounds):
        # Initialise the environment for this game
        environment.init()
        
        # choose the first move using fair toss
        turn = random.choice([-1, 1])

        # if the first turn is opponent's
        if turn == -1:
            environment, opponent_action_performed = play_opponent_turn(environment, opponent)
        
        # Recursively play agent turn and opponent turn until game is end
        while not environment.is_end:
            # Play the agent turn
            environment, agent_action_performed = play_agent_turn(environment, agent)

            # check the winner
            winner = environment.winner()

            # if the winner is not yet decided
            if winner is None:
                # play the opponent turn
                environment, opponent_action_performed = play_opponent_turn(environment, opponent)

            # collect the reward after each turn
            reward = environment.reward()
        # store the reward after each game
        rewards.append(reward)

    # Record the stats for the number of games    
    if(debug == True):
        print("Wins: ",rewards.count(10))
        print("Loss: ",rewards.count(-10))
        print("Ties:", rewards.count(1))

    # return the number of wins
    return rewards.count(10)

# Program to train the agent against opponents
def train(environment, agent, opponents):
    train_wins = []
    # train with train_num_games initialised globally
    for game_num in range(train_num_games):
        # Initialise the environment for this game
        environment.init()

        # Choose one of the opponent for this game
        opponent = random.choice(opponents)

        # choose the first move using fair toss
        turn = random.choice([-1, 1])

        # if the first turn is opponent's
        if turn == -1:
            environment, opponent_action_performed = play_opponent_turn(environment, opponent)
        
        # Recursively play agent turn and opponent turn until game is end
        while not environment.is_end:
            # state before agent turn
            state_before_agent = environment.state()

            # Play the agent turn
            environment, agent_action_performed = play_agent_turn(environment, agent)

            # state after agent turn
            state_after_agent = environment.state()

            # check the winner
            winner = environment.winner()

            # if the winner is not yet decided
            if winner is None:
                # play the opponent turn
                environment, opponent_action_performed = play_opponent_turn(environment, opponent)

                # state after this turn
                state_after_agent = environment.state()
            
            # Observe the environment after this move
            agent.observe(environment, state_before_agent, agent_action_performed, state_after_agent)

        # After every 200 games assess the efficacy of the learning
        if game_num % num_test_trained_agent == 0:
            num_wins = test(environment, agent, opponent)
            train_wins.append(num_wins)

    # return the trained agent
    return agent, train_wins

def plot(random_agent_train, safe_agent_train, both_agent_train):
    plt.xlabel("Epoch")
    plt.ylabel("Wins count")
    epochs = np.arange(0, train_num_games, num_test_trained_agent)
    plt.plot(epochs, random_agent_train, label = "random")
    plt.plot(epochs, safe_agent_train, label = "safe")
    plt.plot(epochs, both_agent_train, label = "both")
    plt.legend()
    plt.show()

# Program start execution
if __name__ == "__main__":
    # create environment 
    environment = Tic_Tac_Toe(board_size)

    # Train against random player
    print("Training against Random Opponents")
    random_opponent = Agent_Random()
    random_agent = Agent_Qlearn()
    random_agent, random_agent_train_wins = train(environment, random_agent, [random_opponent])

    # Train against Safe player
    print("Training against Safe Opponents")
    safe_opponent = Agent_Safe()
    safe_agent = Agent_Qlearn()
    safe_agent, safe_agent_train_wins = train(environment, safe_agent, [safe_opponent])

    # Train with randomly selected opponent
    print("Training against Safe and random Opponents")
    both_agent = Agent_Qlearn()
    both_agent, both_agent_train_wins = train(environment, both_agent,[random_opponent, safe_opponent])

    # plotting all graphs
    plot(random_agent_train_wins, safe_agent_train_wins, both_agent_train_wins)

    # Testing
    # Random Trained vs Random player
    print("Testing Against Random Trained vs Random")
    test(environment, random_agent, random_opponent, test_games, debug=True)

    # Random Trained vs Safe Player
    print("Testing Against Random Trained vs Safe")
    test(environment, random_agent, safe_opponent, test_games, debug=True)

    # Safe Trained vs Random Player
    print("Testing Against Safe Trained vs Random")
    test(environment, safe_agent, random_opponent, test_games, debug=True)

    # Safe Trained vs Safe Player
    print("Testing Against Safe Trained vs Safe")
    test(environment, safe_agent, safe_opponent, test_games, debug=True)

    # Both Trained vs Random Player
    print("Testing Against Both Trained vs Random")
    test(environment, both_agent, random_opponent, test_games, debug=True)

    # Both Trained vs Safe Player
    print("Testing Against Both Trained vs Safe")
    test(environment, both_agent, random_opponent, test_games, debug=True)


""" Question 5d """
# Among the above three, we can see the third agent which is trained against
# Random and Safe players outperforms other agents as it is trained against 
# all possible safe and random moves making it more robust

""" Question 5e """
# The agent cannot be said to be unbeatable by every opponent. But the 
# training process can be improved by optimizing the hyperparameters.
# The training iterations can be increased to make the robot more robust.