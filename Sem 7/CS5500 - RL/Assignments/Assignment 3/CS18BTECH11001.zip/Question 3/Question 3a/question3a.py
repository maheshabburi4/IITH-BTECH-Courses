# required modules
import numpy as np
import matplotlib.pyplot as plt
import random
import gym
import torch
from itertools import count

# parsing the arguments
import argparse as arg
arg_parser = arg.ArgumentParser(description='3a.py')
arg_parser.add_argument("--environment", type=str, help="env")
arg_parser.add_argument("--iterations", type=int, help="number of iterations")
arg_parser.add_argument("--batch", type=int, help="batch_size")

# function to create plot
def plot(rewards):
    plt.figure(figsize=(10,5),dpi=100) 

    plt.title(file_name)
    plt.plot(rewards,label='Mean Reward')
    plt.xlabel('Episodes')
    plt.ylabel('Reward')
    plt.grid()
    plt.savefig(file_name)

# select the action
def select_action(state):
    arg=env.action_space.n
    ret = random.randrange(0,env.action_space.n)
    return ret

# fetch the current state
def get_state(obs):
    state = np.array(obs)
    state = torch.from_numpy(state).type(torch.FloatTensor)
    state = state.unsqueeze(0)
    return state

# training in the environment
def train(env):
    rewards = []
    it=0
    while it < iterations:   
        episode_rewards_batch = []
        episode = 0
        while episode < batch_size:
            obs = env.reset()
            state = get_state(obs)
            episode_rewards = []
            for t in count():
                action= select_action(state)
                a = env.step(action)
                obs = a[0]
                reward = a[1]
                done = a[2]
                info = a[3]
                recall=[]
                state  =  get_state(obs)
                episode_rewards.append(reward)

                if done:
                    break
            episode_rewards_batch.append(episode_rewards)
            episode+=1
        rewards.append(np.mean([np.sum(er) for er in episode_rewards_batch]))
        print('Total Reward for Iteration {} : {}'.format(it,rewards[-1]))
        it+=1    
    env.close()
    plot(rewards)
    return

# extract the given arguments
arguments = arg_parser.parse_args()

# Set the Hyperparameters
batch_size = arguments.batch
iterations = arguments.iterations
env = gym.make(arguments.environment)

# creating file name to save the plot
file_name=arguments.environment+'_'+str(iterations)+'_'+str(batch_size)+'_rand.png'

# training in the environment
train(env)